# 基于SpringBoot+Vue学生管理系统（附完整源码）

## 项目简介

学生管理系统面向学校教务日常管理，覆盖学生、班级、课程、成绩、教务、管理等核心业务。系统分为管理端与客户端：管理端用于基础数据维护与权限设置，客户端支持学生注册、个人信息维护以及课程与成绩查询。采用前后端分离架构，内置演示数据，部署后即可体验完整业务流程。

---

## 技术栈与架构

- **后端**：Spring Boot 3 + MySQL（端口 2001）
- **管理端**：Vue 3（端口 4001）
- **客户端**：Vue 3（端口 3001）
- **架构**：前后端分离，RESTful 接口，导入 SQL 即可本地运行

---

## 功能模块

### 管理端

#### 数据概览

登录管理端后的首页模块，集中展示学生、班级、课程与成绩等核心指标，并通过柱状图、环形图直观呈现数据分布。管理员可在此快速了解整体运行情况，再进入各业务页面处理明细数据。

![数据概览](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/dashboard.png)

#### 学生管理

用于维护学生档案信息，支持按姓名搜索、新增、编辑与删除。表单涵盖学号、姓名、性别、联系方式、所属班级等字段，并可上传头像，满足日常学籍管理需求。

![学生管理](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/student.png)

#### 班级管理

维护各班级基础信息，包括班级名称、年级、专业、班主任及人数等。班级数据与学生、课程业务关联，便于按班组织教学与管理。

![班级管理](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/class.png)

#### 课程管理

管理课程库信息，记录课程编号、名称、学分、授课教师、课时与课程类型等。为成绩录入与选课查询提供统一的数据来源。

![课程管理](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/course.png)

#### 成绩管理

支持按学生、课程录入与查询成绩，列表展示学号、姓名、课程及分数。教师或管理员可在此完成成绩维护，学生端同步可查个人成绩。

![成绩管理](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/grade.png)

#### 角色管理

配置系统角色及权限范围，区分管理员、教师等身份。不同角色登录后可见的菜单与操作权限不同，保证后台使用安全可控。

![角色管理](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/role.png)

#### 菜单管理

管理端侧边栏菜单可在此维护，包括菜单名称、路由路径与图标。支持本地上传图标，配合角色管理实现按权限动态展示菜单。

![菜单管理](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/menu.png)

### 客户端

#### 学生注册

客户端提供学生自助注册入口，填写用户名、学号、姓名、性别、班级及联系方式即可创建账号。注册成功后可直接登录使用个人中心与查询功能。

![学生注册](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/register.png)

#### 个人信息

学生登录后可查看并修改个人资料，包括姓名、手机、邮箱等；支持上传与更换头像。学号、性别等关键信息只读展示，避免误改。

![个人信息](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/profile.png)

#### 我的课程

展示当前学生已选课程列表，包含课程名称、学分、授课教师等信息。便于学生随时查看本学期修读情况。

![我的课程](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/my-courses.png)

#### 我的成绩

按课程列出个人成绩记录，清晰展示各门课得分。学生无需联系管理员即可自助查询，提升使用体验。

![我的成绩](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/my-grades.png)

---

## 快速运行

1. 执行 `sql/` 目录下三个脚本初始化数据库
2. 启动后端：`cd backend && mvn spring-boot:run`
3. 启动管理端：`cd frontend-admin && npm install && npm run dev`
4. 启动客户端：`cd frontend-client && npm install && npm run dev`

**演示账号**

| 端 | 账号 | 密码 |
|----|------|------|
| 管理端 | admin | admin123 |
| 客户端 | student001 | 123456 |

---

## 获取源码

<small>关注公众号，点击下图进入小程序，即可获取完整项目源码与部署说明。</small>

![管理端登录页](https://ruobing-bucket.oss-cn-beijing.aliyuncs.com/articles/StudentManagementSystem/admin-login.png)
