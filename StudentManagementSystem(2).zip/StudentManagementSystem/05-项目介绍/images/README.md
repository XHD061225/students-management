# 文章配图

请将以下截图放入本目录（建议宽度 750px，PNG 格式）：

| 文件名 | 说明 |
|--------|------|
| admin-login.png | 管理端登录页 |
| client-login.png | 客户端登录页 |
| dashboard.png | 管理端数据概览 |
