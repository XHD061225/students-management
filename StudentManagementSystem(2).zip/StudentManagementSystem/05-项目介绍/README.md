# 学生管理系统 — 项目介绍

本目录包含公众号文章原文与配图索引。

| 文件 | 说明 |
|------|------|
| `article.md` | 公众号文章 Markdown 原文 |
| `screenshots.json` | 各模块截图 OSS 地址索引 |

配图文件托管于 OSS，详见 `screenshots.json` 中的 `url` 字段。
