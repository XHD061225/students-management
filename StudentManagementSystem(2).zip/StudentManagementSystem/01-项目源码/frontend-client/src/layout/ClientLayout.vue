<template>
  <div class="layout">
    <header class="header">
      <div class="header-inner">
        <div class="brand">学生管理系统 · 学生端</div>
        <nav class="nav">
          <router-link to="/home">首页</router-link>
          <router-link to="/profile">个人信息</router-link>
          <router-link to="/courses">我的课程</router-link>
          <router-link to="/grades">我的成绩</router-link>
        </nav>
        <div class="user-area">
          <span>{{ userStore.user?.name }}</span>
          <button class="btn btn-ghost" @click="logout">退出</button>
        </div>
      </div>
    </header>
    <main class="main">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'

const router = useRouter()
const userStore = useUserStore()

function logout() {
  userStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.header {
  background: var(--color-surface);
  border-bottom: 1px solid var(--color-border);
  position: sticky;
  top: 0;
  z-index: 10;
}
.header-inner {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 24px;
  height: 64px;
  display: flex;
  align-items: center;
  gap: 32px;
}
.brand { font-weight: 600; color: var(--color-primary-dark); white-space: nowrap; }
.nav { display: flex; gap: 24px; flex: 1; }
.nav a {
  color: var(--color-text-secondary);
  text-decoration: none;
  font-size: 14px;
  transition: color var(--transition);
  cursor: pointer;
}
.nav a:hover, .nav a.router-link-active { color: var(--color-primary); }
.user-area { display: flex; align-items: center; gap: 12px; font-size: 14px; }
.btn-ghost {
  background: transparent;
  border: 1px solid var(--color-border);
  color: var(--color-text-secondary);
  padding: 6px 14px;
}
.main {
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px 24px;
}
</style>
