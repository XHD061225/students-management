import { defineStore } from 'pinia'

import { ref } from 'vue'

import request from '../api/request'



export const useUserStore = defineStore('user', () => {

  const user = ref(JSON.parse(localStorage.getItem('client_user') || 'null'))



  async function login(username, password) {

    const data = await request.post('/auth/login', { username, password }, { params: { portal: 'client' } })

    user.value = data

    localStorage.setItem('client_user', JSON.stringify(data))

    return data

  }



  async function register(payload) {

    return request.post('/auth/register', payload)

  }



  function logout() {

    user.value = null

    localStorage.removeItem('client_user')

  }



  return { user, login, register, logout }

})

