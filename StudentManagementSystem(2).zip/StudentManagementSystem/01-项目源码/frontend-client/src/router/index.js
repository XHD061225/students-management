import { createRouter, createWebHistory } from 'vue-router'

import { useUserStore } from '../stores/user'

import Login from '../views/Login.vue'

import Register from '../views/Register.vue'

import ClientLayout from '../layout/ClientLayout.vue'

import Home from '../views/Home.vue'

import Profile from '../views/Profile.vue'

import MyCourses from '../views/MyCourses.vue'

import MyGrades from '../views/MyGrades.vue'



const publicPaths = ['/login', '/register']



const router = createRouter({

  history: createWebHistory(),

  routes: [

    { path: '/login', component: Login },

    { path: '/register', component: Register },

    {

      path: '/',

      component: ClientLayout,

      redirect: '/home',

      children: [

        { path: 'home', component: Home },

        { path: 'profile', component: Profile },

        { path: 'courses', component: MyCourses },

        { path: 'grades', component: MyGrades }

      ]

    }

  ]

})



router.beforeEach((to) => {

  const userStore = useUserStore()

  if (publicPaths.includes(to.path)) {

    if (userStore.user) return '/home'

    return true

  }

  if (!userStore.user) return '/login'

})



export default router

