<template>
  <div>
    <h2 class="page-title">我的成绩</h2>
    <div class="card">
      <table class="table">
        <thead><tr><th>课程</th><th>分数</th><th>学期</th><th>备注</th></tr></thead>
        <tbody>
          <tr v-for="g in gradeList" :key="g.id">
            <td>{{ g.courseName }}</td><td><span class="score">{{ g.score }}</span></td><td>{{ g.semester }}</td><td>{{ g.remark }}</td>
          </tr>
          <tr v-if="!gradeList.length"><td colspan="4" style="text-align:center;color:#64748B">暂无成绩记录</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useUserStore } from '../stores/user'
import request from '../api/request'

const userStore = useUserStore()
const gradeList = ref([])

onMounted(async () => {
  const grades = await request.get('/grades', { params: { studentId: userStore.user?.studentId } })
  const courses = await request.get('/courses')
  const courseMap = Object.fromEntries(courses.map(c => [c.id, c.courseName]))
  gradeList.value = grades.map(g => ({ ...g, courseName: courseMap[g.courseId] || `课程#${g.courseId}` }))
})
</script>

<style scoped>
.score { font-weight: 600; color: var(--color-primary-dark); }
</style>
