<template>
  <div>
    <h2 class="page-title">你好，{{ userStore.user?.name }}</h2>
    <div class="hero-card card">
      <h3>欢迎使用 学生管理系统</h3>
      <p>在这里你可以查看个人信息、已选课程与成绩记录。</p>
    </div>
    <div class="quick-grid">
      <router-link to="/profile" class="quick-card card">
        <div class="quick-icon profile">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        </div>
        <div><div class="quick-title">个人信息</div><div class="quick-desc">查看与维护个人资料</div></div>
      </router-link>
      <router-link to="/courses" class="quick-card card">
        <div class="quick-icon courses">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
        </div>
        <div><div class="quick-title">我的课程</div><div class="quick-desc">本学期选课一览</div></div>
      </router-link>
      <router-link to="/grades" class="quick-card card">
        <div class="quick-icon grades">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-4"/></svg>
        </div>
        <div><div class="quick-title">我的成绩</div><div class="quick-desc">查询各科目成绩</div></div>
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { useUserStore } from '../stores/user'
const userStore = useUserStore()
</script>

<style scoped>
.hero-card { margin-bottom: 24px; }
.hero-card h3 { margin-bottom: 8px; }
.hero-card p { color: var(--color-text-secondary); font-size: 14px; }
.quick-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; }
.quick-card {
  display: flex;
  align-items: center;
  gap: 16px;
  text-decoration: none;
  color: inherit;
  cursor: pointer;
  transition: transform var(--transition);
}
.quick-card:hover { transform: translateY(-2px); }
.quick-icon {
  width: 48px; height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.quick-icon.profile { background: rgba(14,165,233,0.12); color: #0EA5E9; }
.quick-icon.courses { background: rgba(5,150,105,0.12); color: #059669; }
.quick-icon.grades { background: rgba(217,119,6,0.12); color: #D97706; }
.quick-title { font-weight: 600; margin-bottom: 4px; }
.quick-desc { font-size: 13px; color: var(--color-text-secondary); }
</style>
