<template>
  <div>
    <h2 class="page-title">我的课程</h2>
    <div class="card">
      <table class="table">
        <thead><tr><th>课程编号</th><th>课程名称</th><th>学分</th><th>授课教师</th></tr></thead>
        <tbody>
          <tr v-for="c in courses" :key="c.id">
            <td>{{ c.courseCode }}</td><td>{{ c.courseName }}</td><td>{{ c.credit }}</td><td>{{ c.teacherName }}</td>
          </tr>
          <tr v-if="!courses.length"><td colspan="4" style="text-align:center;color:#64748B">暂无选课记录</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useUserStore } from '../stores/user'
import request from '../api/request'

const userStore = useUserStore()
const courses = ref([])

onMounted(async () => {
  const allCourses = await request.get('/courses')
  const grades = await request.get('/grades', { params: { studentId: userStore.user?.studentId } })
  const courseIds = new Set(grades.map(g => g.courseId))
  courses.value = allCourses.filter(c => courseIds.has(c.id))
})
</script>
