<template>
  <div>
    <h2 class="page-title">个人信息</h2>
    <div class="card profile-card" v-if="student">
      <AvatarUpload v-model="form.avatar" />
      <div class="form-grid">
        <div class="form-group">
          <label>学号</label>
          <input :value="student.studentNo" class="input" disabled />
        </div>
        <div class="form-group">
          <label>姓名</label>
          <input v-model="form.name" class="input" maxlength="50" />
        </div>
        <div class="form-group">
          <label>性别</label>
          <input :value="student.gender" class="input" disabled />
        </div>
        <div class="form-group">
          <label>手机</label>
          <input v-model="form.phone" class="input" maxlength="11" @input="form.phone = form.phone.replace(/\D/g,'').slice(0,11)" />
          <span v-if="errors.phone" class="err">{{ errors.phone }}</span>
        </div>
        <div class="form-group">
          <label>邮箱</label>
          <input v-model="form.email" class="input" maxlength="100" />
          <span v-if="errors.email" class="err">{{ errors.email }}</span>
        </div>
        <div class="form-group full">
          <label>地址</label>
          <input :value="student.address" class="input" disabled />
        </div>
      </div>
      <p v-if="msg" :class="msgOk ? 'msg-ok' : 'err'">{{ msg }}</p>
      <button class="btn btn-primary" @click="save" :disabled="saving">{{ saving ? '保存中...' : '保存修改' }}</button>
    </div>
    <div v-else class="card"><p>加载中...</p></div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { useUserStore } from '../stores/user'
import request from '../api/request'
import AvatarUpload from '../components/AvatarUpload.vue'
import { validatePhone, validateEmail } from '../utils/validators'

const userStore = useUserStore()
const student = ref(null)
const saving = ref(false)
const msg = ref('')
const msgOk = ref(false)
const errors = reactive({ phone: '', email: '' })
const form = reactive({ name: '', phone: '', email: '', avatar: '' })

onMounted(async () => {
  if (!userStore.user?.studentId) return
  student.value = await request.get(`/students/${userStore.user.studentId}`)
  form.name = student.value.name || ''
  form.phone = student.value.phone || ''
  form.email = student.value.email || ''
  form.avatar = student.value.avatar || ''
})

async function save() {
  errors.phone = validatePhone(form.phone)
  errors.email = validateEmail(form.email)
  if (errors.phone || errors.email) return
  saving.value = true
  msg.value = ''
  try {
    const payload = {
      name: form.name,
      phone: form.phone,
      email: form.email,
      avatar: form.avatar?.trim() || null
    }
    const updated = await request.put(`/profile/student/${student.value.id}`, payload)
    student.value = { ...student.value, ...updated }
    form.avatar = updated.avatar || ''
    userStore.user.name = updated.name
    localStorage.setItem('client_user', JSON.stringify(userStore.user))
    msg.value = '保存成功'
    msgOk.value = true
  } catch (e) {
    msg.value = e.message || '保存失败'
    msgOk.value = false
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.profile-card { max-width: 720px; }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.full { grid-column: 1 / -1; }
.form-group label { display: block; font-size: 13px; color: var(--color-text-secondary); margin-bottom: 6px; }
.err { color: #DC2626; font-size: 12px; }
.msg-ok { color: #059669; font-size: 13px; margin-bottom: 12px; }
</style>
