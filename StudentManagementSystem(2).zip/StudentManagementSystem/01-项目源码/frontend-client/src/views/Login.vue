<template>
  <div class="login-page">
    <div class="login-overlay"></div>
    <div class="login-shell">
      <div class="login-card">
        <div class="login-header">
          <span class="portal-badge">学生端</span>
          <h1>学生管理系统</h1>
          <p>欢迎回来，登录后即可查看课程与成绩</p>
        </div>
        <form @submit.prevent="handleLogin">
          <div class="form-group">
            <label>学号账号</label>
            <input v-model="form.username" class="input" placeholder="请输入学号账号" required />
          </div>
          <div class="form-group">
            <label>密码</label>
            <input v-model="form.password" type="password" class="input" placeholder="请输入密码" required />
          </div>
          <p v-if="error" class="error">{{ error }}</p>
          <button class="btn btn-primary" type="submit" :disabled="loading">
            {{ loading ? '登录中...' : '进入系统' }}
          </button>
        </form>
        <p class="register-link">还没有账号？<router-link to="/register">立即注册</router-link></p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'

const router = useRouter()
const userStore = useUserStore()
const loading = ref(false)
const error = ref('')
const form = reactive({ username: 'student001', password: '123456' })

async function handleLogin() {
  loading.value = true
  error.value = ''
  try {
    await userStore.login(form.username, form.password)
    router.push('/home')
  } catch (e) {
    error.value = e.message || '登录失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  position: relative;
  background: url('/resources/images/login/client-bg.svg') center/cover no-repeat fixed;
  background-color: #E8F4FC;
}

.login-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    105deg,
    rgba(255, 255, 255, 0.92) 0%,
    rgba(255, 255, 255, 0.75) 38%,
    rgba(255, 255, 255, 0.15) 62%,
    transparent 100%
  );
  pointer-events: none;
}

.login-shell {
  position: relative;
  z-index: 1;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: 32px clamp(24px, 8vw, 120px);
}

.login-card {
  width: min(420px, 100%);
  padding: 36px 32px;
  background: rgba(255, 255, 255, 0.88);
  backdrop-filter: blur(16px) saturate(1.2);
  border: 1px solid rgba(255, 255, 255, 0.9);
  border-radius: 16px;
  box-shadow:
    0 8px 32px rgba(14, 165, 233, 0.12),
    0 2px 8px rgba(15, 23, 42, 0.06);
  animation: slideIn 0.45s ease-out;
}

@keyframes slideIn {
  from { opacity: 0; transform: translateX(-16px); }
  to { opacity: 1; transform: translateX(0); }
}

.login-header { margin-bottom: 28px; }

.portal-badge {
  display: inline-block;
  padding: 4px 12px;
  margin-bottom: 14px;
  font-size: 12px;
  font-weight: 500;
  color: #0284C7;
  background: rgba(14, 165, 233, 0.1);
  border: 1px solid rgba(14, 165, 233, 0.25);
  border-radius: 20px;
}

.login-header h1 {
  font-size: 26px;
  font-weight: 600;
  color: #0F172A;
  margin-bottom: 8px;
  letter-spacing: -0.02em;
}

.login-header p {
  font-size: 14px;
  color: #64748B;
  line-height: 1.5;
}

.form-group { margin-bottom: 18px; }

.form-group label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
  margin-bottom: 8px;
}

.input {
  background: rgba(255, 255, 255, 0.95);
  border-color: #CBD5E1;
  padding: 11px 14px;
}

.input:focus {
  background: #fff;
}

.btn-primary {
  width: 100%;
  margin-top: 4px;
  padding: 12px;
  font-size: 15px;
  font-weight: 500;
  border-radius: 10px;
}

.error {
  color: #DC2626;
  font-size: 13px;
  margin-bottom: 10px;
  padding: 8px 12px;
  background: rgba(220, 38, 38, 0.06);
  border-radius: 6px;
}

.register-link {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
  color: #64748B;
}

.register-link a {
  color: var(--color-primary);
  font-weight: 500;
  text-decoration: none;
}

.register-link a:hover { text-decoration: underline; }

@media (max-width: 768px) {
  .login-shell {
    justify-content: center;
    padding: 24px 20px;
  }
  .login-overlay {
    background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.85) 0%,
      rgba(255, 255, 255, 0.5) 50%,
      rgba(255, 255, 255, 0.3) 100%
    );
  }
  .login-card {
    background: rgba(255, 255, 255, 0.94);
  }
}
</style>
