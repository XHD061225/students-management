<template>
  <div class="register-page">
    <div class="page-overlay"></div>
    <div class="page-shell">
      <div class="register-card">
        <div class="register-header">
          <span class="portal-badge">学生端</span>
          <h1>学生注册</h1>
          <p>填写信息完成账号注册，注册后可登录客户端</p>
        </div>
        <form @submit.prevent="handleRegister">
          <div class="form-row">
            <div class="form-group">
              <label>登录账号 <span class="req">*</span></label>
              <input v-model="form.username" class="input" maxlength="50" placeholder="用于登录的用户名" required />
            </div>
            <div class="form-group">
              <label>密码 <span class="req">*</span></label>
              <input v-model="form.password" type="password" class="input" maxlength="50" placeholder="至少6位" required />
            </div>
            <div class="form-group">
              <label>学号 <span class="req">*</span></label>
              <input v-model="form.studentNo" class="input" maxlength="20" placeholder="4-20位字母或数字" required />
              <span v-if="errors.studentNo" class="err">{{ errors.studentNo }}</span>
            </div>
            <div class="form-group">
              <label>姓名 <span class="req">*</span></label>
              <input v-model="form.name" class="input" maxlength="50" required />
            </div>
            <div class="form-group">
              <label>性别 <span class="req">*</span></label>
              <select v-model="form.gender" class="select">
                <option value="男">男</option>
                <option value="女">女</option>
              </select>
            </div>
            <div class="form-group">
              <label>班级 <span class="req">*</span></label>
              <select v-model="form.classId" class="select" required>
                <option v-for="c in classes" :key="c.id" :value="c.id">{{ c.className }}</option>
              </select>
            </div>
            <div class="form-group">
              <label>手机 <span class="req">*</span></label>
              <input v-model="form.phone" class="input" maxlength="11" placeholder="11位手机号" />
              <span v-if="errors.phone" class="err">{{ errors.phone }}</span>
            </div>
            <div class="form-group">
              <label>邮箱</label>
              <input v-model="form.email" class="input" maxlength="100" placeholder="example@email.com" />
              <span v-if="errors.email" class="err">{{ errors.email }}</span>
            </div>
          </div>
          <p v-if="error" class="error">{{ error }}</p>
          <button class="btn btn-primary" type="submit" :disabled="loading">{{ loading ? '提交中...' : '注册' }}</button>
        </form>
        <p class="login-link">已有账号？<router-link to="/login">返回登录</router-link></p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import request from '../api/request'
import { useUserStore } from '../stores/user'
import { validatePhone, validateEmail, validateStudentNo } from '../utils/validators'

const router = useRouter()
const userStore = useUserStore()
const loading = ref(false)
const error = ref('')
const classes = ref([])
const errors = reactive({ studentNo: '', phone: '', email: '' })
const form = reactive({
  username: '', password: '', studentNo: '', name: '', gender: '男',
  phone: '', email: '', classId: null
})

onMounted(async () => {
  classes.value = await request.get('/classes')
  if (classes.value.length) form.classId = classes.value[0].id
})

function validate() {
  errors.studentNo = validateStudentNo(form.studentNo)
  errors.phone = validatePhone(form.phone, true)
  errors.email = validateEmail(form.email)
  if (!form.password || form.password.length < 6) {
    error.value = '密码至少6位'
    return false
  }
  return !errors.studentNo && !errors.phone && !errors.email
}

async function handleRegister() {
  error.value = ''
  if (!validate()) return
  loading.value = true
  try {
    await userStore.register({ ...form })
    router.push('/login')
  } catch (e) {
    error.value = e.message || '注册失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.register-page {
  min-height: 100vh;
  position: relative;
  background: url('/resources/images/login/client-bg.svg') center/cover no-repeat fixed;
  background-color: #E8F4FC;
}

.page-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    105deg,
    rgba(255, 255, 255, 0.92) 0%,
    rgba(255, 255, 255, 0.75) 38%,
    rgba(255, 255, 255, 0.15) 62%,
    transparent 100%
  );
  pointer-events: none;
}

.page-shell {
  position: relative;
  z-index: 1;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: 32px clamp(24px, 6vw, 100px);
}

.register-card {
  width: min(560px, 100%);
  padding: 36px 32px;
  background: rgba(255, 255, 255, 0.88);
  backdrop-filter: blur(16px) saturate(1.2);
  border: 1px solid rgba(255, 255, 255, 0.9);
  border-radius: 16px;
  box-shadow:
    0 8px 32px rgba(14, 165, 233, 0.12),
    0 2px 8px rgba(15, 23, 42, 0.06);
  animation: slideIn 0.45s ease-out;
}

@keyframes slideIn {
  from { opacity: 0; transform: translateX(-16px); }
  to { opacity: 1; transform: translateX(0); }
}

.register-header { margin-bottom: 24px; }

.portal-badge {
  display: inline-block;
  padding: 4px 12px;
  margin-bottom: 12px;
  font-size: 12px;
  font-weight: 500;
  color: #0284C7;
  background: rgba(14, 165, 233, 0.1);
  border: 1px solid rgba(14, 165, 233, 0.25);
  border-radius: 20px;
}

.register-header h1 {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 6px;
}

.register-header p {
  font-size: 14px;
  color: #64748B;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.form-group label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
  margin-bottom: 6px;
}

.input, .select {
  background: rgba(255, 255, 255, 0.95);
  border-color: #CBD5E1;
}

.select {
  width: 100%;
  padding: 11px 14px;
  border: 1px solid #CBD5E1;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
}

.req { color: #DC2626; }

.err { color: #DC2626; font-size: 12px; margin-top: 4px; display: block; }

.error {
  color: #DC2626;
  font-size: 13px;
  margin: 12px 0;
  padding: 8px 12px;
  background: rgba(220, 38, 38, 0.06);
  border-radius: 6px;
}

.btn-primary {
  width: 100%;
  margin-top: 16px;
  padding: 12px;
  font-size: 15px;
  font-weight: 500;
  border-radius: 10px;
}

.login-link {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
  color: #64748B;
}

.login-link a {
  color: var(--color-primary);
  font-weight: 500;
  text-decoration: none;
}

@media (max-width: 768px) {
  .page-shell {
    justify-content: center;
    padding: 24px 20px;
  }
  .page-overlay {
    background: linear-gradient(180deg, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0.5) 100%);
  }
}

@media (max-width: 520px) {
  .form-row { grid-template-columns: 1fr; }
}
</style>
