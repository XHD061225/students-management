package com.autogen.studentmgmt.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "course")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 20)
    private String courseCode;

    @Column(nullable = false, length = 100)
    private String courseName;

    private Integer credit;

    @Column(length = 50)
    private String teacherName;

    @Column(length = 20)
    private String courseType;

    private Integer hours;

    @Column(length = 200)
    private String description;
}
