package com.autogen.studentmgmt.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Entity
@Table(name = "grade")
public class Grade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long studentId;

    private Long courseId;

    private BigDecimal score;

    @Column(length = 10)
    private String gradeLevel;

    @Column(length = 20)
    private String semester;

    @Column(length = 20)
    private String examType;

    @Column(length = 200)
    private String remark;
}
