package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.dto.ProfileUpdateRequest;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.entity.User;
import com.autogen.studentmgmt.repository.StudentRepository;
import com.autogen.studentmgmt.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class ProfileService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final ValidationHelper validationHelper;

    public User getUserProfile(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new BusinessException("用户不存在"));
    }

    @Transactional
    public User updateUserProfile(Long userId, ProfileUpdateRequest req) {
        User user = getUserProfile(userId);
        if (req.getName() != null) user.setName(req.getName());
        if (req.getPhone() != null) user.setPhone(req.getPhone());
        if (req.getEmail() != null) user.setEmail(req.getEmail());
        user.setAvatar(StringUtils.hasText(req.getAvatar()) ? req.getAvatar().trim() : null);
        validationHelper.validateUserProfile(user);
        return userRepository.save(user);
    }

    @Transactional
    public Student updateStudentProfile(Long studentId, ProfileUpdateRequest req) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new BusinessException("学生不存在"));
        if (req.getName() != null) student.setName(req.getName());
        if (req.getPhone() != null) student.setPhone(req.getPhone());
        if (req.getEmail() != null) student.setEmail(req.getEmail());
        student.setAvatar(StringUtils.hasText(req.getAvatar()) ? req.getAvatar().trim() : null);
        validationHelper.validatePhone(student.getPhone(), false);
        validationHelper.validateEmail(student.getEmail());
        Student saved = studentRepository.save(student);
        if (student.getUserId() != null) {
            userRepository.findById(student.getUserId()).ifPresent(u -> {
                u.setName(saved.getName());
                u.setPhone(saved.getPhone());
                u.setEmail(saved.getEmail());
                u.setAvatar(saved.getAvatar());
                userRepository.save(u);
            });
        }
        return saved;
    }
}
