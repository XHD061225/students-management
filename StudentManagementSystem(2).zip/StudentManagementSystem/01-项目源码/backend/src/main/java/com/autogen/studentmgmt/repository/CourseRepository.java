package com.autogen.studentmgmt.repository;

import com.autogen.studentmgmt.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByCourseNameContaining(String courseName);
}
