package com.autogen.studentmgmt.controller;

import com.autogen.studentmgmt.common.Result;
import com.autogen.studentmgmt.dto.LoginRequest;
import com.autogen.studentmgmt.dto.LoginResponse;
import com.autogen.studentmgmt.dto.RegisterRequest;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.service.AuthService;
import com.autogen.studentmgmt.service.RegisterService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final RegisterService registerService;

    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest request,
                                       @RequestParam(defaultValue = "admin") String portal) {
        return Result.ok(authService.login(request, portal));
    }

    @PostMapping("/register")
    public Result<Student> register(@RequestBody RegisterRequest request) {
        return Result.ok(registerService.registerStudent(request));
    }
}
