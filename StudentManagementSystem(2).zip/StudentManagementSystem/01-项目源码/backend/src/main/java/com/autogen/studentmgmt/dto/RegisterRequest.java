package com.autogen.studentmgmt.dto;

import lombok.Data;

@Data
public class RegisterRequest {
    private String username;
    private String password;
    private String name;
    private String studentNo;
    private String gender;
    private String phone;
    private String email;
    private Long classId;
}
