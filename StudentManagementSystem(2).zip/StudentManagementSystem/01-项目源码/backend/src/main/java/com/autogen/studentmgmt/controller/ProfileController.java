package com.autogen.studentmgmt.controller;

import com.autogen.studentmgmt.common.Result;
import com.autogen.studentmgmt.dto.ProfileUpdateRequest;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.entity.User;
import com.autogen.studentmgmt.service.ProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final ProfileService profileService;

    @GetMapping("/user/{userId}")
    public Result<User> getUser(@PathVariable Long userId) {
        return Result.ok(profileService.getUserProfile(userId));
    }

    @PutMapping("/user/{userId}")
    public Result<User> updateUser(@PathVariable Long userId, @RequestBody ProfileUpdateRequest req) {
        return Result.ok(profileService.updateUserProfile(userId, req));
    }

    @PutMapping("/student/{studentId}")
    public Result<Student> updateStudent(@PathVariable Long studentId, @RequestBody ProfileUpdateRequest req) {
        return Result.ok(profileService.updateStudentProfile(studentId, req));
    }
}
