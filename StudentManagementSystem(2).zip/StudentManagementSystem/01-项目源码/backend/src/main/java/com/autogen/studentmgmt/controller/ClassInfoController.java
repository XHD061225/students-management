package com.autogen.studentmgmt.controller;

import com.autogen.studentmgmt.common.Result;
import com.autogen.studentmgmt.entity.ClassInfo;
import com.autogen.studentmgmt.service.ClassInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/classes")
@RequiredArgsConstructor
public class ClassInfoController {

    private final ClassInfoService classInfoService;

    @GetMapping
    public Result<List<ClassInfo>> list(@RequestParam(required = false) String keyword) {
        return Result.ok(classInfoService.list(keyword));
    }

    @GetMapping("/{id}")
    public Result<ClassInfo> get(@PathVariable Long id) {
        return Result.ok(classInfoService.getById(id));
    }

    @PostMapping
    public Result<ClassInfo> create(@RequestBody ClassInfo classInfo) {
        return Result.ok(classInfoService.save(classInfo));
    }

    @PutMapping("/{id}")
    public Result<ClassInfo> update(@PathVariable Long id, @RequestBody ClassInfo classInfo) {
        classInfo.setId(id);
        return Result.ok(classInfoService.save(classInfo));
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        classInfoService.delete(id);
        return Result.ok();
    }
}
