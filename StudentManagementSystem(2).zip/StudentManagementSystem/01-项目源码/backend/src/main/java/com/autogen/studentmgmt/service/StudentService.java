package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final ValidationHelper validationHelper;

    public List<Student> list(String keyword) {
        if (StringUtils.hasText(keyword)) {
            return studentRepository.findByNameContaining(keyword);
        }
        return studentRepository.findAll();
    }

    public Student getById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new BusinessException("学生不存在"));
    }

    public Student save(Student student) {
        boolean isCreate = student.getId() == null;
        validationHelper.validateStudent(student, isCreate);
        if (!isCreate) {
            Student existing = getById(student.getId());
            if (!existing.getStudentNo().equals(student.getStudentNo())) {
                throw new BusinessException("学号不允许修改");
            }
        }
        return studentRepository.save(student);
    }

    public void delete(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new BusinessException("学生不存在");
        }
        studentRepository.deleteById(id);
    }
}
