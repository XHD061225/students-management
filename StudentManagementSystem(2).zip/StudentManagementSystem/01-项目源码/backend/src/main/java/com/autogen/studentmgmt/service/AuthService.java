package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.dto.LoginRequest;
import com.autogen.studentmgmt.dto.LoginResponse;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.entity.User;
import com.autogen.studentmgmt.repository.StudentRepository;
import com.autogen.studentmgmt.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthService {

    private static final Set<String> ADMIN_PORTAL_ROLES = Set.of("ADMIN", "TEACHER");
    private static final Set<String> CLIENT_PORTAL_ROLES = Set.of("STUDENT");

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;

    public LoginResponse login(LoginRequest request, String portal) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new BusinessException("用户名或密码错误"));
        if (!user.getPassword().equals(request.getPassword())) {
            throw new BusinessException("用户名或密码错误");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new BusinessException("账号已禁用");
        }
        validatePortal(user.getRole(), portal);
        Long studentId = studentRepository.findByUserId(user.getId())
                .map(Student::getId)
                .orElse(null);
        String token = UUID.randomUUID().toString().replace("-", "");
        return new LoginResponse(user.getId(), user.getUsername(), user.getName(),
                user.getRole(), token, studentId);
    }

    private void validatePortal(String role, String portal) {
        if ("admin".equals(portal) && !ADMIN_PORTAL_ROLES.contains(role)) {
            throw new BusinessException("请使用客户端登录");
        }
        if ("client".equals(portal) && !CLIENT_PORTAL_ROLES.contains(role)) {
            throw new BusinessException("请使用管理端登录");
        }
    }
}
