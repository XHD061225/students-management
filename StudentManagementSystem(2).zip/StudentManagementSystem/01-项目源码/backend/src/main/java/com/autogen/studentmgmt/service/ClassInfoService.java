package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.entity.ClassInfo;
import com.autogen.studentmgmt.repository.ClassInfoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ClassInfoService {

    private final ClassInfoRepository classInfoRepository;

    public List<ClassInfo> list(String keyword) {
        if (StringUtils.hasText(keyword)) {
            return classInfoRepository.findByClassNameContaining(keyword);
        }
        return classInfoRepository.findAll();
    }

    public ClassInfo getById(Long id) {
        return classInfoRepository.findById(id)
                .orElseThrow(() -> new BusinessException("班级不存在"));
    }

    public ClassInfo save(ClassInfo classInfo) {
        return classInfoRepository.save(classInfo);
    }

    public void delete(Long id) {
        classInfoRepository.deleteById(id);
    }
}
