package com.autogen.studentmgmt.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStats {
    private long studentCount;
    private long classCount;
    private long courseCount;
    private long gradeCount;
    private List<ChartItem> classDistribution = new ArrayList<>();
    private List<ChartItem> gradeLevelDistribution = new ArrayList<>();
    private List<ChartItem> genderDistribution = new ArrayList<>();
}
