package com.autogen.studentmgmt.controller;

import com.autogen.studentmgmt.common.Result;
import com.autogen.studentmgmt.entity.Grade;
import com.autogen.studentmgmt.service.GradeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grades")
@RequiredArgsConstructor
public class GradeController {

    private final GradeService gradeService;

    @GetMapping
    public Result<List<Grade>> list(@RequestParam(required = false) Long studentId) {
        if (studentId != null) {
            return Result.ok(gradeService.listByStudent(studentId));
        }
        return Result.ok(gradeService.list());
    }

    @GetMapping("/{id}")
    public Result<Grade> get(@PathVariable Long id) {
        return Result.ok(gradeService.getById(id));
    }

    @PostMapping
    public Result<Grade> create(@RequestBody Grade grade) {
        return Result.ok(gradeService.save(grade));
    }

    @PutMapping("/{id}")
    public Result<Grade> update(@PathVariable Long id, @RequestBody Grade grade) {
        grade.setId(id);
        return Result.ok(gradeService.save(grade));
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        gradeService.delete(id);
        return Result.ok();
    }
}
