package com.autogen.studentmgmt.controller;

import com.autogen.studentmgmt.common.Result;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    public Result<List<Student>> list(@RequestParam(required = false) String keyword) {
        return Result.ok(studentService.list(keyword));
    }

    @GetMapping("/{id}")
    public Result<Student> get(@PathVariable Long id) {
        return Result.ok(studentService.getById(id));
    }

    @PostMapping
    public Result<Student> create(@RequestBody Student student) {
        return Result.ok(studentService.save(student));
    }

    @PutMapping("/{id}")
    public Result<Student> update(@PathVariable Long id, @RequestBody Student student) {
        student.setId(id);
        return Result.ok(studentService.save(student));
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        studentService.delete(id);
        return Result.ok();
    }
}
