package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.entity.Grade;
import com.autogen.studentmgmt.repository.GradeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GradeService {

    private final GradeRepository gradeRepository;

    public List<Grade> list() {
        return gradeRepository.findAll();
    }

    public List<Grade> listByStudent(Long studentId) {
        return gradeRepository.findByStudentId(studentId);
    }

    public Grade getById(Long id) {
        return gradeRepository.findById(id)
                .orElseThrow(() -> new BusinessException("成绩记录不存在"));
    }

    public Grade save(Grade grade) {
        return gradeRepository.save(grade);
    }

    public void delete(Long id) {
        gradeRepository.deleteById(id);
    }
}
