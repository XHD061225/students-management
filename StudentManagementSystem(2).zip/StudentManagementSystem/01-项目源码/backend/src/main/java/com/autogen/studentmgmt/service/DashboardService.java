package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.dto.ChartItem;
import com.autogen.studentmgmt.dto.DashboardStats;
import com.autogen.studentmgmt.entity.ClassInfo;
import com.autogen.studentmgmt.entity.Grade;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final StudentRepository studentRepository;
    private final ClassInfoRepository classInfoRepository;
    private final CourseRepository courseRepository;
    private final GradeRepository gradeRepository;

    public DashboardStats getStats() {
        DashboardStats stats = new DashboardStats();
        stats.setStudentCount(studentRepository.count());
        stats.setClassCount(classInfoRepository.count());
        stats.setCourseCount(courseRepository.count());
        stats.setGradeCount(gradeRepository.count());
        stats.setClassDistribution(buildClassDistribution());
        stats.setGradeLevelDistribution(buildGradeLevelDistribution());
        stats.setGenderDistribution(buildGenderDistribution());
        return stats;
    }

    private List<ChartItem> buildClassDistribution() {
        return classInfoRepository.findAll().stream()
                .sorted(Comparator.comparing(ClassInfo::getClassName))
                .map(c -> new ChartItem(c.getClassName(), c.getStudentCount() != null ? c.getStudentCount() : 0))
                .collect(Collectors.toList());
    }

    private List<ChartItem> buildGradeLevelDistribution() {
        Map<String, Long> map = new LinkedHashMap<>();
        for (Grade g : gradeRepository.findAll()) {
            String level = StringUtils.hasText(g.getGradeLevel()) ? g.getGradeLevel() : "未评";
            map.merge(level, 1L, Long::sum);
        }
        return map.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByKey().reversed())
                .map(e -> new ChartItem(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    private List<ChartItem> buildGenderDistribution() {
        Map<String, Long> map = new LinkedHashMap<>();
        for (Student s : studentRepository.findAll()) {
            String gender = StringUtils.hasText(s.getGender()) ? s.getGender() : "未知";
            map.merge(gender, 1L, Long::sum);
        }
        return map.entrySet().stream()
                .map(e -> new ChartItem(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }
}
