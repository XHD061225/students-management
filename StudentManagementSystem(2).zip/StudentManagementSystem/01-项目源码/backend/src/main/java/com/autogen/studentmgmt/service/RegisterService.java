package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.dto.RegisterRequest;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.entity.User;
import com.autogen.studentmgmt.repository.StudentRepository;
import com.autogen.studentmgmt.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RegisterService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final ValidationHelper validationHelper;

    @Transactional
    public Student registerStudent(RegisterRequest req) {
        if (userRepository.findByUsername(req.getUsername()).isPresent()) {
            throw new BusinessException("用户名已存在");
        }
        if (studentRepository.findByStudentNo(req.getStudentNo()).isPresent()) {
            throw new BusinessException("学号已存在");
        }
        validationHelper.validatePhone(req.getPhone(), true);
        validationHelper.validateEmail(req.getEmail());

        User user = new User();
        user.setUsername(req.getUsername());
        user.setPassword(req.getPassword());
        user.setRole("STUDENT");
        user.setName(req.getName());
        user.setPhone(req.getPhone());
        user.setEmail(req.getEmail());
        user.setStatus(1);
        user = userRepository.save(user);

        Student student = new Student();
        student.setStudentNo(req.getStudentNo());
        student.setName(req.getName());
        student.setGender(req.getGender());
        student.setPhone(req.getPhone());
        student.setEmail(req.getEmail());
        student.setClassId(req.getClassId());
        student.setUserId(user.getId());
        student.setStatus(1);
        return studentRepository.save(student);
    }
}
