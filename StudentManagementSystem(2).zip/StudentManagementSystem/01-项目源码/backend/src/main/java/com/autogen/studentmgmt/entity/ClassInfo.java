package com.autogen.studentmgmt.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "class_info")
public class ClassInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String className;

    @Column(length = 20)
    private String grade;

    @Column(length = 50)
    private String major;

    @Column(length = 50)
    private String headTeacher;

    private Integer studentCount = 0;

    @Column(length = 200)
    private String description;
}
