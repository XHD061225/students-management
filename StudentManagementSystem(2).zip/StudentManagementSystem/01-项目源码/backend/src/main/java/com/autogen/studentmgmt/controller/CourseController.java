package com.autogen.studentmgmt.controller;

import com.autogen.studentmgmt.common.Result;
import com.autogen.studentmgmt.entity.Course;
import com.autogen.studentmgmt.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @GetMapping
    public Result<List<Course>> list(@RequestParam(required = false) String keyword) {
        return Result.ok(courseService.list(keyword));
    }

    @GetMapping("/{id}")
    public Result<Course> get(@PathVariable Long id) {
        return Result.ok(courseService.getById(id));
    }

    @PostMapping
    public Result<Course> create(@RequestBody Course course) {
        return Result.ok(courseService.save(course));
    }

    @PutMapping("/{id}")
    public Result<Course> update(@PathVariable Long id, @RequestBody Course course) {
        course.setId(id);
        return Result.ok(courseService.save(course));
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        courseService.delete(id);
        return Result.ok();
    }
}
