package com.autogen.studentmgmt.service;

import com.autogen.studentmgmt.common.BusinessException;
import com.autogen.studentmgmt.entity.Student;
import com.autogen.studentmgmt.entity.User;
import com.autogen.studentmgmt.repository.StudentRepository;
import com.autogen.studentmgmt.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ValidationHelper {

    private static final Pattern PHONE = Pattern.compile("^1\\d{10}$");
    private static final Pattern EMAIL = Pattern.compile("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern STUDENT_NO = Pattern.compile("^[A-Za-z0-9]{4,20}$");

    public void validatePhone(String phone, boolean required) {
        if (!StringUtils.hasText(phone)) {
            if (required) throw new BusinessException("手机号不能为空");
            return;
        }
        if (phone.length() != 11 || !PHONE.matcher(phone).matches()) {
            throw new BusinessException("手机号必须为11位且以1开头");
        }
    }

    public void validateEmail(String email) {
        if (StringUtils.hasText(email) && !EMAIL.matcher(email).matches()) {
            throw new BusinessException("邮箱格式不正确");
        }
    }

    public void validateStudent(Student student, boolean isCreate) {
        if (!StringUtils.hasText(student.getName())) {
            throw new BusinessException("姓名不能为空");
        }
        if (student.getName().length() > 50) {
            throw new BusinessException("姓名长度不能超过50");
        }
        if (!StringUtils.hasText(student.getStudentNo())) {
            throw new BusinessException("学号不能为空");
        }
        if (!STUDENT_NO.matcher(student.getStudentNo()).matches()) {
            throw new BusinessException("学号仅支持4-20位字母或数字");
        }
        if (isCreate && studentRepository.findByStudentNo(student.getStudentNo()).isPresent()) {
            throw new BusinessException("学号已存在");
        }
        validatePhone(student.getPhone(), false);
        validateEmail(student.getEmail());
        if (student.getClassId() == null) {
            throw new BusinessException("请选择班级");
        }
        if (!StringUtils.hasText(student.getGender())) {
            throw new BusinessException("请选择性别");
        }
    }

    public void validateUserProfile(User user) {
        if (!StringUtils.hasText(user.getName())) {
            throw new BusinessException("姓名不能为空");
        }
        validatePhone(user.getPhone(), false);
        validateEmail(user.getEmail());
    }

    private final StudentRepository studentRepository;
}
