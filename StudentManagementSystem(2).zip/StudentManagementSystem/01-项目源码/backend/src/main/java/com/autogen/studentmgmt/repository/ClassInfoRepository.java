package com.autogen.studentmgmt.repository;

import com.autogen.studentmgmt.entity.ClassInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClassInfoRepository extends JpaRepository<ClassInfo, Long> {
    List<ClassInfo> findByClassNameContaining(String className);
}
