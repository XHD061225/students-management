<template>

  <div class="layout">

    <aside class="sidebar">

      <div class="brand">

        <div class="brand-icon">

          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">

            <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

          </svg>

        </div>

        <div>

          <div class="brand-title">学生管理系统</div>

          <div class="brand-sub">管理端 · {{ roleLabel }}</div>

        </div>

      </div>

      <nav class="nav">

        <router-link v-for="item in navMenus" :key="item.path" :to="item.path" class="nav-item">

          <span v-html="item.icon"></span>

          {{ item.label }}

        </router-link>

      </nav>

    </aside>

    <div class="main">

      <header class="header">

        <div class="header-title">{{ currentTitle }}</div>

        <div class="header-user">

          <router-link to="/profile" class="profile-link">{{ userStore.user?.name }}</router-link>

          <button class="btn btn-ghost" @click="logout">退出</button>

        </div>

      </header>

      <main class="content">

        <router-view />

      </main>

    </div>

  </div>

</template>



<script setup>

import { computed, onMounted } from 'vue'

import { useRoute, useRouter } from 'vue-router'

import { useUserStore } from '../stores/user'

import { menuIcon } from '../utils/menuIcons'



const route = useRoute()

const router = useRouter()

const userStore = useUserStore()



const roleLabels = { ADMIN: '管理员', TEACHER: '教师' }

const roleLabel = computed(() => roleLabels[userStore.user?.role] || '')



const navMenus = computed(() =>

  userStore.menus.map(m => ({

    path: m.path,

    label: m.title,

    icon: menuIcon(m.icon)

  }))

)



const currentTitle = computed(() =>

  navMenus.value.find(m => m.path === route.path)?.label || ''

)



onMounted(async () => {

  if (userStore.user && !userStore.menus.length) {

    await userStore.fetchMenus(userStore.user.role)

  }

})



function logout() {

  userStore.logout()

  router.push('/login')

}

</script>



<style scoped>

.layout { display: flex; min-height: 100vh; }

.sidebar {

  width: var(--sidebar-width);

  background: var(--color-surface);

  border-right: 1px solid var(--color-border);

  padding: 20px 0;

  position: fixed;

  top: 0; bottom: 0; left: 0;

}

.brand {

  display: flex;

  gap: 12px;

  align-items: center;

  padding: 0 20px 24px;

  border-bottom: 1px solid var(--color-border);

  margin-bottom: 16px;

}

.brand-icon {

  width: 40px; height: 40px;

  background: var(--color-primary);

  color: #fff;

  border-radius: 8px;

  display: flex;

  align-items: center;

  justify-content: center;

}

.brand-title { font-weight: 600; font-size: 15px; }

.brand-sub { font-size: 12px; color: var(--color-text-secondary); }

.nav { display: flex; flex-direction: column; gap: 4px; padding: 0 12px; }

.nav-item {

  display: flex;

  align-items: center;

  gap: 10px;

  padding: 10px 12px;

  border-radius: 6px;

  color: var(--color-text-secondary);

  transition: all var(--transition);

  cursor: pointer;

}

.nav-item:hover, .nav-item.router-link-active {

  background: rgba(30, 64, 175, 0.08);

  color: var(--color-primary);

}

.main {

  flex: 1;

  margin-left: var(--sidebar-width);

  display: flex;

  flex-direction: column;

}

.header {

  height: 60px;

  background: var(--color-surface);

  border-bottom: 1px solid var(--color-border);

  display: flex;

  align-items: center;

  justify-content: space-between;

  padding: 0 24px;

}

.header-title { font-weight: 600; }

.header-user { display: flex; align-items: center; gap: 12px; font-size: 14px; }

.profile-link { color: var(--color-primary); cursor: pointer; text-decoration: none; }

.profile-link:hover { text-decoration: underline; }

.content { padding: 24px; flex: 1; }

</style>

