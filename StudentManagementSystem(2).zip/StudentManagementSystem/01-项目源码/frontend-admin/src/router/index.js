import { createRouter, createWebHistory } from 'vue-router'

import { useUserStore } from '../stores/user'

import Login from '../views/Login.vue'

import AdminLayout from '../layout/AdminLayout.vue'

import Dashboard from '../views/Dashboard.vue'

import Students from '../views/Students.vue'

import Classes from '../views/Classes.vue'

import Courses from '../views/Courses.vue'

import Grades from '../views/Grades.vue'

import Roles from '../views/Roles.vue'

import Menus from '../views/Menus.vue'

import Profile from '../views/Profile.vue'



const router = createRouter({

  history: createWebHistory(),

  routes: [

    { path: '/login', component: Login },

    {

      path: '/',

      component: AdminLayout,

      redirect: '/dashboard',

      children: [

        { path: 'dashboard', component: Dashboard },

        { path: 'students', component: Students },

        { path: 'classes', component: Classes },

        { path: 'courses', component: Courses },

        { path: 'grades', component: Grades },

        { path: 'roles', component: Roles },

        { path: 'menus', component: Menus },

        { path: 'profile', component: Profile }

      ]

    }

  ]

})



router.beforeEach(async (to) => {

  const userStore = useUserStore()

  if (to.path === '/login') {

    if (userStore.user) return '/dashboard'

    return true

  }

  if (!userStore.user) return '/login'

  if (!userStore.menus.length) {

    await userStore.fetchMenus(userStore.user.role)

  }

  const allowed = userStore.menus.map(m => m.path)

  if (to.path !== '/' && allowed.length && !allowed.includes(to.path)) {

    return allowed[0] || '/login'

  }

})



export default router

