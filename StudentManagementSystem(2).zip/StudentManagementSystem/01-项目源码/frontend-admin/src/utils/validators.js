export function validatePhone(phone, required = false) {
  if (!phone?.trim()) return required ? '手机号不能为空' : ''
  if (phone.length > 11) return '手机号最多11位'
  if (!/^1\d{0,10}$/.test(phone)) return '手机号必须以1开头且为数字'
  if (phone.length === 11 && !/^1\d{10}$/.test(phone)) return '手机号格式不正确'
  return ''
}

export function validateEmail(email) {
  if (!email?.trim()) return ''
  if (!/^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$/.test(email)) return '邮箱格式不正确'
  return ''
}

export function validateStudentNo(no) {
  if (!no?.trim()) return '学号不能为空'
  if (!/^[A-Za-z0-9]{4,20}$/.test(no)) return '学号仅支持4-20位字母或数字'
  return ''
}
