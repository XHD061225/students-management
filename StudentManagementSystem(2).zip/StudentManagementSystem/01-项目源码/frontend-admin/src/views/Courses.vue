<template>
  <div>
    <div class="toolbar">
      <h2 class="page-title">课程管理</h2>
      <button class="btn btn-primary" @click="openForm()">新增课程</button>
    </div>
    <div class="card">
      <table class="table">
        <thead><tr><th>课程编号</th><th>课程名称</th><th>学分</th><th>类型</th><th>授课教师</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="item in list" :key="item.id">
            <td>{{ item.courseCode }}</td><td>{{ item.courseName }}</td><td>{{ item.credit }}</td>
            <td>{{ item.courseType || '—' }}</td><td>{{ item.teacherName }}</td>
            <td>
              <button class="btn btn-ghost" @click="openForm(item)">编辑</button>
              <button class="btn btn-danger" @click="remove(item)">删除</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="showModal" class="modal-mask" @click.self="showModal = false">
      <div class="modal">
        <h3>{{ form.id ? '编辑课程' : '新增课程' }}</h3>
        <div class="form-group"><label>课程编号 <span class="req">*</span></label><input v-model="form.courseCode" class="input" maxlength="20" :readonly="!!form.id" /></div>
        <div class="form-group"><label>课程名称 <span class="req">*</span></label><input v-model="form.courseName" class="input" maxlength="100" /></div>
        <div class="form-group"><label>学分</label><input v-model.number="form.credit" type="number" min="1" max="10" class="input" /></div>
        <div class="form-group"><label>类型</label><select v-model="form.courseType" class="select"><option>必修</option><option>选修</option></select></div>
        <div class="form-group"><label>授课教师</label><input v-model="form.teacherName" class="input" maxlength="50" /></div>
        <p v-if="formError" class="err">{{ formError }}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" @click="showModal = false">取消</button>
          <button class="btn btn-primary" @click="save">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import request from '../api/request'
import { showConfirm } from '../composables/useConfirm'

const list = ref([])
const showModal = ref(false)
const formError = ref('')
const form = reactive({ id: null, courseCode: '', courseName: '', credit: 3, courseType: '必修', teacherName: '', description: '' })

async function load() { list.value = await request.get('/courses') }

function openForm(item) {
  formError.value = ''
  Object.assign(form, { id: null, courseCode: '', courseName: '', credit: 3, courseType: '必修', teacherName: '', description: '' })
  if (item) {
    form.id = item.id
    form.courseCode = item.courseCode ?? ''
    form.courseName = item.courseName ?? ''
    form.credit = item.credit ?? 3
    form.courseType = item.courseType ?? '必修'
    form.teacherName = item.teacherName ?? ''
    form.description = item.description ?? ''
  }
  showModal.value = true
}

async function save() {
  if (!form.courseCode?.trim() || !form.courseName?.trim()) { formError.value = '课程编号和名称不能为空'; return }
  formError.value = ''
  try {
    if (form.id) await request.put(`/courses/${form.id}`, form)
    else await request.post('/courses', form)
    showModal.value = false
    load()
  } catch (e) { formError.value = e.message }
}

async function remove(item) {
  const ok = await showConfirm('删除课程', `确定删除课程「${item.courseName}」吗？`)
  if (!ok) return
  try { await request.delete(`/courses/${item.id}`); load() }
  catch (e) { formError.value = e.message }
}

onMounted(load)
</script>

<style scoped>
.toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.table .btn { margin-right: 8px; padding: 4px 10px; font-size: 13px; }
.req { color: var(--color-danger); }
.err { color: var(--color-danger); font-size: 13px; margin-bottom: 8px; }
</style>
