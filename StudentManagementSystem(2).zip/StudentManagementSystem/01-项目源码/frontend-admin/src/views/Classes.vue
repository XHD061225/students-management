<template>
  <div>
    <div class="toolbar">
      <h2 class="page-title">班级管理</h2>
      <button class="btn btn-primary" @click="openForm()">新增班级</button>
    </div>
    <div class="card">
      <table class="table">
        <thead><tr><th>班级名称</th><th>年级</th><th>专业</th><th>班主任</th><th>人数</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="item in list" :key="item.id">
            <td>{{ item.className }}</td><td>{{ item.grade }}</td><td>{{ item.major }}</td>
            <td>{{ item.headTeacher || '—' }}</td><td>{{ item.studentCount ?? 0 }}</td>
            <td>
              <button class="btn btn-ghost" @click="openForm(item)">编辑</button>
              <button class="btn btn-danger" @click="remove(item)">删除</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="showModal" class="modal-mask" @click.self="showModal = false">
      <div class="modal">
        <h3>{{ form.id ? '编辑班级' : '新增班级' }}</h3>
        <div class="form-group"><label>班级名称 <span class="req">*</span></label><input v-model="form.className" class="input" maxlength="50" /></div>
        <div class="form-group"><label>年级</label><input v-model="form.grade" class="input" maxlength="20" /></div>
        <div class="form-group"><label>专业</label><input v-model="form.major" class="input" maxlength="50" /></div>
        <div class="form-group"><label>班主任</label><input v-model="form.headTeacher" class="input" maxlength="50" /></div>
        <div class="form-group"><label>描述</label><input v-model="form.description" class="input" maxlength="200" /></div>
        <p v-if="formError" class="err">{{ formError }}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" @click="showModal = false">取消</button>
          <button class="btn btn-primary" @click="save">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import request from '../api/request'
import { showConfirm } from '../composables/useConfirm'

const list = ref([])
const showModal = ref(false)
const formError = ref('')
const form = reactive({ id: null, className: '', grade: '', major: '', headTeacher: '', description: '' })

async function load() { list.value = await request.get('/classes') }

function openForm(item) {
  formError.value = ''
  Object.assign(form, { id: null, className: '', grade: '', major: '', headTeacher: '', description: '' })
  if (item) {
    form.id = item.id
    form.className = item.className ?? ''
    form.grade = item.grade ?? ''
    form.major = item.major ?? ''
    form.headTeacher = item.headTeacher ?? ''
    form.description = item.description ?? ''
  }
  showModal.value = true
}

async function save() {
  if (!form.className?.trim()) { formError.value = '班级名称不能为空'; return }
  formError.value = ''
  try {
    if (form.id) await request.put(`/classes/${form.id}`, form)
    else await request.post('/classes', form)
    showModal.value = false
    load()
  } catch (e) { formError.value = e.message }
}

async function remove(item) {
  const ok = await showConfirm('删除班级', `确定删除班级「${item.className}」吗？`)
  if (!ok) return
  try { await request.delete(`/classes/${item.id}`); load() }
  catch (e) { formError.value = e.message }
}

onMounted(load)
</script>

<style scoped>
.toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.table .btn { margin-right: 8px; padding: 4px 10px; font-size: 13px; }
.req { color: var(--color-danger); }
.err { color: var(--color-danger); font-size: 13px; margin-bottom: 8px; }
</style>
