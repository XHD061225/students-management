<template>
  <div>
    <div class="toolbar">
      <h2 class="page-title">成绩管理</h2>
      <button class="btn btn-primary" @click="openForm()">录入成绩</button>
    </div>
    <div class="card">
      <table class="table">
        <thead><tr><th>学生</th><th>课程</th><th>分数</th><th>等级</th><th>学期</th><th>备注</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="item in list" :key="item.id">
            <td>{{ studentMap[item.studentId] || item.studentId }}</td>
            <td>{{ courseMap[item.courseId] || item.courseId }}</td>
            <td>{{ item.score }}</td>
            <td>{{ item.gradeLevel || '—' }}</td>
            <td>{{ item.semester }}</td>
            <td>{{ item.remark || '—' }}</td>
            <td>
              <button class="btn btn-ghost" @click="openForm(item)">编辑</button>
              <button class="btn btn-danger" @click="remove(item)">删除</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="showModal" class="modal-mask" @click.self="showModal = false">
      <div class="modal">
        <h3>{{ form.id ? '编辑成绩' : '录入成绩' }}</h3>
        <div class="form-group">
          <label>学生 <span class="req">*</span></label>
          <select v-model="form.studentId" class="select">
            <option v-for="s in students" :key="s.id" :value="s.id">{{ s.name }}（{{ s.studentNo }}）</option>
          </select>
        </div>
        <div class="form-group">
          <label>课程 <span class="req">*</span></label>
          <select v-model="form.courseId" class="select">
            <option v-for="c in courses" :key="c.id" :value="c.id">{{ c.courseName }}</option>
          </select>
        </div>
        <div class="form-group">
          <label>分数</label>
          <input v-model.number="form.score" type="number" min="0" max="100" step="0.1" class="input" />
        </div>
        <div class="form-group"><label>学期</label><input v-model="form.semester" class="input" maxlength="20" placeholder="2024-2025-1" /></div>
        <div class="form-group"><label>备注</label><input v-model="form.remark" class="input" maxlength="200" /></div>
        <p v-if="formError" class="err">{{ formError }}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" @click="showModal = false">取消</button>
          <button class="btn btn-primary" @click="save">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import request from '../api/request'
import { showConfirm } from '../composables/useConfirm'

const list = ref([])
const students = ref([])
const courses = ref([])
const showModal = ref(false)
const formError = ref('')
const form = reactive({ id: null, studentId: null, courseId: null, score: 80, semester: '2024-2025-1', remark: '' })

const studentMap = computed(() => Object.fromEntries(students.value.map(s => [s.id, s.name])))
const courseMap = computed(() => Object.fromEntries(courses.value.map(c => [c.id, c.courseName])))

async function load() {
  list.value = await request.get('/grades')
  students.value = await request.get('/students')
  courses.value = await request.get('/courses')
}

function openForm(item) {
  formError.value = ''
  Object.assign(form, { id: null, studentId: students.value[0]?.id, courseId: courses.value[0]?.id, score: 80, semester: '2024-2025-1', remark: '' })
  if (item) {
    form.id = item.id
    form.studentId = item.studentId
    form.courseId = item.courseId
    form.score = item.score
    form.semester = item.semester ?? ''
    form.remark = item.remark ?? ''
  }
  showModal.value = true
}

async function save() {
  if (!form.studentId || !form.courseId) { formError.value = '请选择学生和课程'; return }
  if (form.score != null && (form.score < 0 || form.score > 100)) { formError.value = '分数范围为0-100'; return }
  formError.value = ''
  try {
    if (form.id) await request.put(`/grades/${form.id}`, form)
    else await request.post('/grades', form)
    showModal.value = false
    load()
  } catch (e) { formError.value = e.message }
}

async function remove(item) {
  const ok = await showConfirm('删除成绩', `确定删除该成绩记录吗？`)
  if (!ok) return
  try { await request.delete(`/grades/${item.id}`); load() }
  catch (e) { formError.value = e.message }
}

onMounted(load)
</script>

<style scoped>
.toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.table .btn { margin-right: 8px; padding: 4px 10px; font-size: 13px; }
.req { color: var(--color-danger); }
.err { color: var(--color-danger); font-size: 13px; margin-bottom: 8px; }
</style>
