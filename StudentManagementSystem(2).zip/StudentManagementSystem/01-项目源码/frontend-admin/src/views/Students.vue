<template>
  <div>
    <div class="toolbar">
      <h2 class="page-title">学生管理</h2>
      <div class="actions">
        <input v-model="keyword" class="input search" placeholder="搜索姓名..." maxlength="50" @keyup.enter="load" />
        <button class="btn btn-primary" @click="openForm()">新增学生</button>
      </div>
    </div>
    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>学号</th><th>姓名</th><th>性别</th><th>手机</th><th>班级</th><th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in list" :key="item.id">
            <td>{{ item.studentNo }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.gender }}</td>
            <td>{{ item.phone || '—' }}</td>
            <td>{{ classNameMap[item.classId] || '—' }}</td>
            <td>
              <button class="btn btn-ghost" @click="openForm(item)">编辑</button>
              <button class="btn btn-danger" @click="remove(item)">删除</button>
            </td>
          </tr>
          <tr v-if="!list.length"><td colspan="6" class="empty">暂无数据</td></tr>
        </tbody>
      </table>
    </div>

    <div v-if="showModal" class="modal-mask" @click.self="closeForm">
      <div class="modal modal-lg">
        <h3>{{ form.id ? '编辑学生' : '新增学生' }}</h3>
        <div class="form-row">
          <div class="form-group">
            <label>学号 <span class="req">*</span></label>
            <input v-model="form.studentNo" class="input" maxlength="20" :readonly="!!form.id" placeholder="4-20位字母或数字" />
            <span v-if="errors.studentNo" class="err">{{ errors.studentNo }}</span>
          </div>
          <div class="form-group">
            <label>姓名 <span class="req">*</span></label>
            <input v-model="form.name" class="input" maxlength="50" />
            <span v-if="errors.name" class="err">{{ errors.name }}</span>
          </div>
          <div class="form-group">
            <label>性别 <span class="req">*</span></label>
            <select v-model="form.gender" class="select">
              <option value="男">男</option>
              <option value="女">女</option>
            </select>
          </div>
          <div class="form-group">
            <label>手机</label>
            <input v-model="form.phone" class="input" maxlength="11" placeholder="11位手机号" @input="onPhoneInput" />
            <span v-if="errors.phone" class="err">{{ errors.phone }}</span>
          </div>
          <div class="form-group">
            <label>邮箱</label>
            <input v-model="form.email" class="input" maxlength="100" placeholder="example@email.com" />
            <span v-if="errors.email" class="err">{{ errors.email }}</span>
          </div>
          <div class="form-group">
            <label>班级 <span class="req">*</span></label>
            <select v-model="form.classId" class="select">
              <option v-for="c in classes" :key="c.id" :value="c.id">{{ c.className }}</option>
            </select>
            <span v-if="errors.classId" class="err">{{ errors.classId }}</span>
          </div>
          <div class="form-group full">
            <label>地址</label>
            <input v-model="form.address" class="input" maxlength="200" />
          </div>
          <div class="form-group full">
            <label>头像</label>
            <AvatarUpload v-model="form.avatar" />
          </div>
        </div>
        <p v-if="formError" class="form-error">{{ formError }}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" @click="closeForm">取消</button>
          <button class="btn btn-primary" @click="save" :disabled="saving">{{ saving ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import request from '../api/request'
import { showConfirm } from '../composables/useConfirm'
import AvatarUpload from '../components/AvatarUpload.vue'
import { validatePhone, validateEmail, validateStudentNo } from '../utils/validators'

const list = ref([])
const classes = ref([])
const keyword = ref('')
const showModal = ref(false)
const saving = ref(false)
const formError = ref('')
const errors = reactive({ studentNo: '', name: '', phone: '', email: '', classId: '' })

const emptyForm = () => ({
  id: null, studentNo: '', name: '', gender: '男', phone: '', email: '',
  classId: null, address: '', avatar: ''
})
const form = reactive(emptyForm())

const classNameMap = computed(() =>
  Object.fromEntries(classes.value.map(c => [c.id, c.className]))
)

async function loadClasses() {
  classes.value = await request.get('/classes')
}

async function load() {
  list.value = await request.get('/students', { params: { keyword: keyword.value || undefined } })
}

function resetErrors() {
  Object.keys(errors).forEach(k => { errors[k] = '' })
  formError.value = ''
}

function onPhoneInput() {
  form.phone = form.phone.replace(/\D/g, '').slice(0, 11)
}

function validateForm() {
  resetErrors()
  errors.studentNo = validateStudentNo(form.studentNo)
  if (!form.name?.trim()) errors.name = '姓名不能为空'
  errors.phone = validatePhone(form.phone)
  errors.email = validateEmail(form.email)
  if (!form.classId) errors.classId = '请选择班级'
  return !Object.values(errors).some(Boolean)
}

function openForm(item) {
  resetErrors()
  Object.assign(form, emptyForm())
  if (item) {
    form.id = item.id
    form.studentNo = item.studentNo ?? ''
    form.name = item.name ?? ''
    form.gender = item.gender ?? '男'
    form.phone = item.phone ?? ''
    form.email = item.email ?? ''
    form.classId = item.classId ?? null
    form.address = item.address ?? ''
    form.avatar = item.avatar ?? ''
  } else if (classes.value.length) {
    form.classId = classes.value[0].id
  }
  showModal.value = true
}

function closeForm() {
  showModal.value = false
  resetErrors()
}

async function save() {
  if (!validateForm()) return
  saving.value = true
  formError.value = ''
  try {
    const payload = { ...form }
    if (!payload.avatar?.trim()) payload.avatar = null
    if (form.id) await request.put(`/students/${form.id}`, payload)
    else await request.post('/students', payload)
    closeForm()
    load()
  } catch (e) {
    formError.value = e.message || '保存失败'
  } finally {
    saving.value = false
  }
}

async function remove(item) {
  const ok = await showConfirm('删除学生', `确定删除学生「${item.name}」（${item.studentNo}）吗？此操作不可恢复。`)
  if (!ok) return
  try {
    await request.delete(`/students/${item.id}`)
    load()
  } catch (e) {
    formError.value = e.message
  }
}

onMounted(async () => {
  await loadClasses()
  load()
})
</script>

<style scoped>
.toolbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 16px; }
.actions { display: flex; gap: 12px; }
.search { width: 200px; }
.table .btn { margin-right: 8px; padding: 4px 10px; font-size: 13px; }
.empty { text-align: center; color: var(--color-text-secondary); padding: 24px !important; }
.modal-lg { width: min(640px, 94vw); }
.full { grid-column: 1 / -1; }
.req { color: var(--color-danger); }
.err { color: var(--color-danger); font-size: 12px; margin-top: 4px; display: block; }
.form-error { color: var(--color-danger); font-size: 13px; margin-bottom: 12px; }
</style>
