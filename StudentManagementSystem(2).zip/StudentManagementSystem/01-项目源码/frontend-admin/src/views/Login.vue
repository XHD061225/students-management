<template>
  <div class="login-page">
    <div class="login-overlay"></div>
    <div class="login-shell">
      <div class="login-card">
        <div class="login-header">
          <span class="portal-badge">管理端</span>
          <h1>学生管理系统</h1>
          <p>管理员与教师工作台</p>
        </div>
        <form @submit.prevent="handleLogin">
          <div class="form-group">
            <label>用户名</label>
            <input v-model="form.username" class="input" placeholder="admin 或 teacher01" required />
          </div>
          <div class="form-group">
            <label>密码</label>
            <input v-model="form.password" type="password" class="input" placeholder="请输入密码" required />
          </div>
          <p v-if="error" class="error">{{ error }}</p>
          <button class="btn btn-primary login-btn" type="submit" :disabled="loading">
            {{ loading ? '登录中...' : '登录' }}
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'

const router = useRouter()
const userStore = useUserStore()
const loading = ref(false)
const error = ref('')
const form = reactive({ username: 'admin', password: 'admin123' })

async function handleLogin() {
  loading.value = true
  error.value = ''
  try {
    await userStore.login(form.username, form.password)
    router.push('/dashboard')
  } catch (e) {
    error.value = e.message || '登录失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  position: relative;
  background: url('/resources/images/login/admin-bg.svg') center/cover no-repeat fixed;
  background-color: #EFF6FF;
}

.login-overlay {
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 70% 60% at 50% 55%, rgba(255, 255, 255, 0.55) 0%, transparent 70%),
    linear-gradient(180deg, rgba(248, 250, 252, 0.4) 0%, transparent 30%, transparent 70%, rgba(248, 250, 252, 0.5) 100%);
  pointer-events: none;
}

.login-shell {
  position: relative;
  z-index: 1;
  min-height: 100vh;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: clamp(48px, 12vh, 120px) 24px 32px;
}

.login-card {
  width: min(400px, 100%);
  padding: 36px 32px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(20px) saturate(1.15);
  border: 1px solid rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  box-shadow:
    0 12px 40px rgba(30, 64, 175, 0.14),
    0 4px 12px rgba(15, 23, 42, 0.08);
  animation: fadeUp 0.45s ease-out;
}

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.login-header {
  text-align: center;
  margin-bottom: 28px;
}

.portal-badge {
  display: inline-block;
  padding: 4px 12px;
  margin-bottom: 14px;
  font-size: 12px;
  font-weight: 500;
  color: #1E40AF;
  background: rgba(30, 64, 175, 0.08);
  border: 1px solid rgba(30, 64, 175, 0.2);
  border-radius: 20px;
}

.login-header h1 {
  font-size: 24px;
  font-weight: 600;
  color: #1E293B;
  margin-bottom: 6px;
}

.login-header p {
  font-size: 14px;
  color: #64748B;
}

.form-group { margin-bottom: 18px; }

.form-group label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
  margin-bottom: 8px;
}

.input {
  background: rgba(255, 255, 255, 0.95);
  border-color: #CBD5E1;
  padding: 11px 14px;
}

.input:focus { background: #fff; }

.login-btn {
  width: 100%;
  margin-top: 4px;
  padding: 12px;
  font-size: 15px;
  font-weight: 500;
  border-radius: 10px;
}

.error {
  color: var(--color-danger);
  font-size: 13px;
  margin-bottom: 10px;
  padding: 8px 12px;
  background: rgba(220, 38, 38, 0.06);
  border-radius: 6px;
}

@media (max-width: 768px) {
  .login-shell {
    align-items: center;
    padding: 24px 20px;
  }
  .login-card {
    background: rgba(255, 255, 255, 0.94);
  }
}
</style>
