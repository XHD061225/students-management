<template>
  <div>
    <h2 class="page-title">数据概览</h2>
    <div class="stats-grid">
      <div v-for="item in statCards" :key="item.label" class="stat-card card">
        <div class="stat-icon" :style="{ background: item.bg }" v-html="item.icon"></div>
        <div>
          <div class="stat-value">{{ item.value }}</div>
          <div class="stat-label">{{ item.label }}</div>
        </div>
      </div>
    </div>

    <div class="charts-grid">
      <div class="card chart-card">
        <h3 class="chart-title">班级人数分布</h3>
        <div v-if="classData.length" class="bar-chart">
          <div v-for="item in classData" :key="item.name" class="bar-row">
            <span class="bar-label">{{ item.name }}</span>
            <div class="bar-track">
              <div class="bar-fill" :style="{ width: barWidth(item.value, classMax) + '%', background: '#1E40AF' }"></div>
            </div>
            <span class="bar-value">{{ item.value }}</span>
          </div>
        </div>
        <p v-else class="empty">暂无数据</p>
      </div>

      <div class="card chart-card">
        <h3 class="chart-title">成绩等级分布</h3>
        <div v-if="gradeData.length" class="donut-wrap">
          <svg viewBox="0 0 120 120" class="donut">
            <circle cx="60" cy="60" r="44" fill="none" stroke="#E2E8F0" stroke-width="16"/>
            <circle
              v-for="(seg, i) in gradeSegments"
              :key="seg.name"
              cx="60" cy="60" r="44"
              fill="none"
              :stroke="seg.color"
              stroke-width="16"
              :stroke-dasharray="seg.dash"
              :stroke-dashoffset="seg.offset"
              transform="rotate(-90 60 60)"
            />
          </svg>
          <ul class="legend">
            <li v-for="item in gradeData" :key="item.name">
              <span class="dot" :style="{ background: colorOf(item.name, gradeColors) }"></span>
              {{ item.name }} · {{ item.value }}
            </li>
          </ul>
        </div>
        <p v-else class="empty">暂无数据</p>
      </div>

      <div class="card chart-card">
        <h3 class="chart-title">学生性别比例</h3>
        <div v-if="genderData.length" class="donut-wrap">
          <svg viewBox="0 0 120 120" class="donut">
            <circle cx="60" cy="60" r="44" fill="none" stroke="#E2E8F0" stroke-width="16"/>
            <circle
              v-for="seg in genderSegments"
              :key="seg.name"
              cx="60" cy="60" r="44"
              fill="none"
              :stroke="seg.color"
              stroke-width="16"
              :stroke-dasharray="seg.dash"
              :stroke-dashoffset="seg.offset"
              transform="rotate(-90 60 60)"
            />
          </svg>
          <ul class="legend">
            <li v-for="item in genderData" :key="item.name">
              <span class="dot" :style="{ background: colorOf(item.name, genderColors) }"></span>
              {{ item.name }} · {{ item.value }}（{{ percent(item.value, genderTotal) }}%）
            </li>
          </ul>
        </div>
        <p v-else class="empty">暂无数据</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import request from '../api/request'

const statCards = ref([
  { label: '学生总数', value: 0, bg: 'rgba(30,64,175,0.1)', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1E40AF" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>' },
  { label: '班级总数', value: 0, bg: 'rgba(5,150,105,0.1)', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>' },
  { label: '课程总数', value: 0, bg: 'rgba(217,119,6,0.1)', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>' },
  { label: '成绩记录', value: 0, bg: 'rgba(59,130,246,0.1)', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" stroke-width="2"><path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-4"/></svg>' }
])

const classData = ref([])
const gradeData = ref([])
const genderData = ref([])

const gradeColors = { A: '#059669', B: '#3B82F6', C: '#D97706', D: '#DC2626', 未评: '#94A3B8' }
const genderColors = { 男: '#1E40AF', 女: '#DB2777', 未知: '#94A3B8' }

const classMax = computed(() => Math.max(...classData.value.map(d => d.value), 1))
const genderTotal = computed(() => genderData.value.reduce((s, d) => s + d.value, 0))

const gradeSegments = computed(() => buildDonutSegments(gradeData.value, gradeColors))
const genderSegments = computed(() => buildDonutSegments(genderData.value, genderColors))

function barWidth(value, max) {
  return Math.round((value / max) * 100)
}

function percent(value, total) {
  if (!total) return 0
  return Math.round((value / total) * 100)
}

function colorOf(name, map) {
  return map[name] || '#64748B'
}

function buildDonutSegments(data, colorMap) {
  const total = data.reduce((s, d) => s + d.value, 0)
  if (!total) return []
  const circumference = 2 * Math.PI * 44
  let offset = 0
  return data.map(item => {
    const ratio = item.value / total
    const length = ratio * circumference
    const seg = {
      name: item.name,
      color: colorOf(item.name, colorMap),
      dash: `${length} ${circumference - length}`,
      offset: -offset
    }
    offset += length
    return seg
  })
}

onMounted(async () => {
  const data = await request.get('/dashboard/stats')
  const values = [data.studentCount, data.classCount, data.courseCount, data.gradeCount]
  statCards.value.forEach((c, i) => { c.value = values[i] })
  classData.value = data.classDistribution || []
  gradeData.value = data.gradeLevelDistribution || []
  genderData.value = data.genderDistribution || []
})
</script>

<style scoped>
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}
.stat-card { display: flex; align-items: center; gap: 16px; }
.stat-icon {
  width: 48px; height: 48px;
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
}
.stat-value { font-size: 28px; font-weight: 600; }
.stat-label { font-size: 13px; color: var(--color-text-secondary); }

.charts-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 16px;
}
.chart-card { padding: 20px; }
.chart-title {
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 20px;
  color: var(--color-text);
}
.empty { color: var(--color-text-secondary); font-size: 14px; text-align: center; padding: 24px; }

.bar-chart { display: flex; flex-direction: column; gap: 14px; }
.bar-row { display: grid; grid-template-columns: 88px 1fr 32px; align-items: center; gap: 10px; }
.bar-label { font-size: 13px; color: var(--color-text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bar-track { height: 10px; background: #F1F5F9; border-radius: 5px; overflow: hidden; }
.bar-fill { height: 100%; border-radius: 5px; transition: width 0.5s ease; min-width: 4px; }
.bar-value { font-size: 13px; font-weight: 600; text-align: right; }

.donut-wrap { display: flex; align-items: center; gap: 24px; flex-wrap: wrap; justify-content: center; }
.donut { width: 140px; height: 140px; flex-shrink: 0; }
.legend { list-style: none; display: flex; flex-direction: column; gap: 8px; }
.legend li { font-size: 13px; color: var(--color-text-secondary); display: flex; align-items: center; gap: 8px; }
.dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
</style>
