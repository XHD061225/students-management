-- 学生管理系统 — 完整 SQL（建库 + 表结构 + Mock 数据）
-- 生成时间: 2026-06-06 12:06:42
-- 数据库: rb_sms

-- 学生管理系统 — 创建数据库
-- MySQL 8.x · 账号 root

CREATE DATABASE IF NOT EXISTS `rb_sms`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `rb_sms`;


-- ============================================================
-- 来源: 02_schema.sql
-- ============================================================

-- 学生管理系统 — 数据库完整结构
-- 数据库：rb_sms · MySQL 8.x
-- 执行顺序：01_create_database.sql → 本文件 → 03_mock_data.sql

USE `rb_sms`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 清理旧表（重建时使用）
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
DROP TABLE IF EXISTS `sys_menu`;
DROP TABLE IF EXISTS `sys_role`;
DROP TABLE IF EXISTS `grade`;
DROP TABLE IF EXISTS `enrollment`;
DROP TABLE IF EXISTS `student`;
DROP TABLE IF EXISTS `course`;
DROP TABLE IF EXISTS `class_info`;
DROP TABLE IF EXISTS `sys_user`;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------
-- 1. 系统用户表
-- ----------------------------
CREATE TABLE `sys_user` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username`    VARCHAR(50)  NOT NULL COMMENT '登录账号',
  `password`    VARCHAR(100) NOT NULL COMMENT '登录密码',
  `role`        VARCHAR(20)  NOT NULL COMMENT '角色：ADMIN/TEACHER/STUDENT',
  `name`        VARCHAR(50)  NOT NULL COMMENT '姓名',
  `phone`       VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  `email`       VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `avatar`      VARCHAR(500) DEFAULT NULL COMMENT '头像URL',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1启用 0禁用',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户';

-- ----------------------------
-- 2. 班级表
-- ----------------------------
CREATE TABLE `class_info` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `class_name`  VARCHAR(50)  NOT NULL COMMENT '班级名称',
  `grade`       VARCHAR(20)  DEFAULT NULL COMMENT '年级',
  `major`       VARCHAR(50)  DEFAULT NULL COMMENT '专业',
  `head_teacher` VARCHAR(50) DEFAULT NULL COMMENT '班主任',
  `student_count` INT        NOT NULL DEFAULT 0 COMMENT '学生人数',
  `description` VARCHAR(200) DEFAULT NULL COMMENT '描述',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_class_name` (`class_name`),
  KEY `idx_grade_major` (`grade`, `major`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='班级';

-- ----------------------------
-- 3. 学生表
-- ----------------------------
CREATE TABLE `student` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_no`  VARCHAR(20)  NOT NULL COMMENT '学号',
  `name`        VARCHAR(50)  NOT NULL COMMENT '姓名',
  `gender`      VARCHAR(10)  DEFAULT NULL COMMENT '性别',
  `birth_date`  DATE         DEFAULT NULL COMMENT '出生日期',
  `phone`       VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  `email`       VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `avatar`      VARCHAR(500) DEFAULT NULL COMMENT '头像URL',
  `class_id`    BIGINT       DEFAULT NULL COMMENT '班级ID',
  `user_id`     BIGINT       DEFAULT NULL COMMENT '关联用户ID',
  `address`     VARCHAR(200) DEFAULT NULL COMMENT '地址',
  `enroll_date` DATE         DEFAULT NULL COMMENT '入学日期',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1在读 0休学 2毕业',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_no` (`student_no`),
  KEY `idx_class_id` (`class_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_name` (`name`),
  CONSTRAINT `fk_student_class` FOREIGN KEY (`class_id`) REFERENCES `class_info` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_student_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='学生';

-- ----------------------------
-- 4. 课程表
-- ----------------------------
CREATE TABLE `course` (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `course_code`  VARCHAR(20)  NOT NULL COMMENT '课程编号',
  `course_name`  VARCHAR(100) NOT NULL COMMENT '课程名称',
  `credit`       INT          DEFAULT NULL COMMENT '学分',
  `teacher_name` VARCHAR(50)  DEFAULT NULL COMMENT '授课教师',
  `course_type`  VARCHAR(20)  DEFAULT '必修' COMMENT '课程类型：必修/选修',
  `hours`        INT          DEFAULT NULL COMMENT '学时',
  `description`  VARCHAR(200) DEFAULT NULL COMMENT '课程描述',
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_code` (`course_code`),
  KEY `idx_course_name` (`course_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程';

-- ----------------------------
-- 5. 选课记录表
-- ----------------------------
CREATE TABLE `enrollment` (
  `id`          BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_id`  BIGINT      NOT NULL COMMENT '学生ID',
  `course_id`   BIGINT      NOT NULL COMMENT '课程ID',
  `semester`    VARCHAR(20) DEFAULT NULL COMMENT '学期',
  `enroll_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '选课时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_course_semester` (`student_id`, `course_id`, `semester`),
  KEY `idx_enrollment_course` (`course_id`),
  CONSTRAINT `fk_enrollment_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_enrollment_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='选课记录';

-- ----------------------------
-- 6. 成绩表
-- ----------------------------
CREATE TABLE `grade` (
  `id`          BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_id`  BIGINT        NOT NULL COMMENT '学生ID',
  `course_id`   BIGINT        NOT NULL COMMENT '课程ID',
  `score`       DECIMAL(5,1)  DEFAULT NULL COMMENT '分数',
  `grade_level` VARCHAR(10)   DEFAULT NULL COMMENT '等级：A/B/C/D/F',
  `semester`    VARCHAR(20)   DEFAULT NULL COMMENT '学期',
  `exam_type`   VARCHAR(20)   DEFAULT '期末' COMMENT '考试类型',
  `remark`      VARCHAR(200)  DEFAULT NULL COMMENT '备注',
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '录入时间',
  PRIMARY KEY (`id`),
  KEY `idx_grade_student` (`student_id`),
  KEY `idx_grade_course` (`course_id`),
  KEY `idx_grade_semester` (`semester`),
  CONSTRAINT `fk_grade_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_grade_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成绩';

-- ----------------------------
-- 7. 角色表
-- ----------------------------
CREATE TABLE `sys_role` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `role_code`   VARCHAR(20)  NOT NULL COMMENT '角色编码',
  `role_name`   VARCHAR(50)  NOT NULL COMMENT '角色名称',
  `description` VARCHAR(200) DEFAULT NULL COMMENT '描述',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '1启用 0禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_code` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色';

-- ----------------------------
-- 8. 菜单表
-- ----------------------------
CREATE TABLE `sys_menu` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `parent_id`   BIGINT       NOT NULL DEFAULT 0 COMMENT '父菜单ID',
  `title`       VARCHAR(50)  NOT NULL COMMENT '菜单名称',
  `path`        VARCHAR(100) NOT NULL COMMENT '路由路径',
  `icon`        VARCHAR(50)  DEFAULT NULL COMMENT '图标标识',
  `sort_order`  INT          NOT NULL DEFAULT 0 COMMENT '排序',
  `portal`      VARCHAR(20)  NOT NULL DEFAULT 'admin' COMMENT '端：admin/client',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '1启用 0禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='菜单';

-- ----------------------------
-- 9. 角色菜单关联
-- ----------------------------
CREATE TABLE `sys_role_menu` (
  `id`      BIGINT NOT NULL AUTO_INCREMENT,
  `role_id` BIGINT NOT NULL,
  `menu_id` BIGINT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_menu` (`role_id`, `menu_id`),
  CONSTRAINT `fk_rm_role` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rm_menu` FOREIGN KEY (`menu_id`) REFERENCES `sys_menu` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色菜单';


-- ============================================================
-- 来源: 03_mock_data.sql
-- ============================================================

-- 学生管理系统 — Mock 测试数据
-- 数据库：rb_sms · 请先执行 01、02
-- 默认登录：admin/admin123 · student001/123456 · teacher01/123456

USE `rb_sms`;

SET NAMES utf8mb4;

-- ----------------------------
-- 系统用户（1 管理员 + 2 教师 + 6 学生）
-- ----------------------------
INSERT INTO `sys_user` (`username`, `password`, `role`, `name`, `phone`, `email`, `avatar`, `status`) VALUES
('admin',      'admin123', 'ADMIN',   '系统管理员', '13900000000', 'admin@school.edu.cn',    NULL, 1),
('teacher01',  '123456',   'TEACHER', '张伟',       '13900000001', 'zhangwei@school.edu.cn', NULL, 1),
('teacher02',  '123456',   'TEACHER', '李娟',       '13900000002', 'lijuan@school.edu.cn',   NULL, 1),
('student001', '123456',   'STUDENT', '李明',       '13800000001', 'liming@stu.edu.cn',      NULL, 1),
('student002', '123456',   'STUDENT', '王芳',       '13800000002', 'wangfang@stu.edu.cn',    NULL, 1),
('student003', '123456',   'STUDENT', '赵强',       '13800000003', 'zhaoqiang@stu.edu.cn',   NULL, 1),
('student004', '123456',   'STUDENT', '刘洋',       '13800000004', 'liuyang@stu.edu.cn',     NULL, 1),
('student005', '123456',   'STUDENT', '陈静',       '13800000005', 'chenjing@stu.edu.cn',    NULL, 1),
('student006', '123456',   'STUDENT', '周磊',       '13800000006', 'zhoulei@stu.edu.cn',     NULL, 1);

-- ----------------------------
-- 班级
-- ----------------------------
INSERT INTO `class_info` (`class_name`, `grade`, `major`, `head_teacher`, `student_count`, `description`) VALUES
('计算机2201班', '2022级', '计算机科学与技术', '张伟', 4, '2022级计算机科学与技术1班'),
('计算机2202班', '2022级', '计算机科学与技术', '张伟', 2, '2022级计算机科学与技术2班'),
('软件2201班',   '2022级', '软件工程',         '李娟', 2, '2022级软件工程1班');

-- ----------------------------
-- 学生
-- ----------------------------
INSERT INTO `student` (`student_no`, `name`, `gender`, `birth_date`, `phone`, `email`, `avatar`, `class_id`, `user_id`, `address`, `enroll_date`, `status`) VALUES
('2022001001', '李明', '男', '2004-03-15', '13800000001', 'liming@stu.edu.cn',      NULL, 1, 4, '北京市海淀区中关村大街1号',   '2022-09-01', 1),
('2022001002', '王芳', '女', '2004-06-22', '13800000002', 'wangfang@stu.edu.cn',    NULL, 1, 5, '北京市朝阳区望京西路10号',    '2022-09-01', 1),
('2022001003', '赵强', '男', '2004-01-08', '13800000003', 'zhaoqiang@stu.edu.cn',   NULL, 1, 6, '北京市丰台区南四环西路88号',  '2022-09-01', 1),
('2022001004', '刘洋', '男', '2004-11-30', '13800000004', 'liuyang@stu.edu.cn',     NULL, 1, 7, '北京市西城区西单北大街5号',   '2022-09-01', 1),
('2022002001', '陈静', '女', '2004-08-17', '13800000005', 'chenjing@stu.edu.cn',    NULL, 2, 8, '北京市东城区王府井大街88号',  '2022-09-01', 1),
('2022002002', '周磊', '男', '2004-05-03', '13800000006', 'zhoulei@stu.edu.cn',     NULL, 2, 9, '北京市昌平区回龙观西大街6号', '2022-09-01', 1);

-- ----------------------------
-- 课程
-- ----------------------------
INSERT INTO `course` (`course_code`, `course_name`, `credit`, `teacher_name`, `course_type`, `hours`, `description`) VALUES
('CS101', 'Java程序设计',     4, '张伟', '必修', 64,  '面向对象程序设计、集合框架、IO与多线程'),
('CS102', '数据库原理',       3, '张伟', '必修', 48,  '关系模型、SQL、事务与索引优化'),
('CS103', 'Web前端开发',      3, '李娟', '必修', 48,  'HTML/CSS/JavaScript 与 Vue 框架'),
('CS104', '软件工程',         3, '李娟', '必修', 48,  '需求分析、UML、敏捷开发流程'),
('CS105', '计算机网络',       3, '张伟', '选修', 48,  'TCP/IP、HTTP、网络安全基础'),
('CS106', 'Python数据分析',   2, '李娟', '选修', 32,  'NumPy/Pandas 数据处理与可视化');

-- ----------------------------
-- 选课记录（2024-2025-1 学期）
-- ----------------------------
INSERT INTO `enrollment` (`student_id`, `course_id`, `semester`) VALUES
(1, 1, '2024-2025-1'), (1, 2, '2024-2025-1'), (1, 3, '2024-2025-1'),
(2, 1, '2024-2025-1'), (2, 3, '2024-2025-1'), (2, 4, '2024-2025-1'),
(3, 1, '2024-2025-1'), (3, 2, '2024-2025-1'), (3, 5, '2024-2025-1'),
(4, 2, '2024-2025-1'), (4, 4, '2024-2025-1'), (4, 6, '2024-2025-1'),
(5, 3, '2024-2025-1'), (5, 4, '2024-2025-1'), (5, 6, '2024-2025-1'),
(6, 1, '2024-2025-1'), (6, 5, '2024-2025-1'), (6, 6, '2024-2025-1');

-- ----------------------------
-- 成绩
-- ----------------------------
INSERT INTO `grade` (`student_id`, `course_id`, `score`, `grade_level`, `semester`, `exam_type`, `remark`) VALUES
(1, 1, 88.5, 'B', '2024-2025-1', '期末', '项目实践表现良好'),
(1, 2, 92.0, 'A', '2024-2025-1', '期末', 'SQL 编写规范'),
(1, 3, 85.0, 'B', '2024-2025-1', '期末', '前端页面完成度高'),
(2, 1, 76.0, 'C', '2024-2025-1', '期末', '需加强算法练习'),
(2, 3, 90.0, 'A', '2024-2025-1', '期末', 'UI 设计优秀'),
(2, 4, 82.0, 'B', '2024-2025-1', '期末', '需求文档清晰'),
(3, 1, 95.0, 'A', '2024-2025-1', '期末', '代码质量高'),
(3, 2, 88.0, 'B', '2024-2025-1', '期末', '索引设计合理'),
(3, 5, 79.0, 'C', '2024-2025-1', '期末', '理论掌握较好'),
(4, 2, 86.5, 'B', '2024-2025-1', '期末', '实验报告完整'),
(4, 4, 91.0, 'A', '2024-2025-1', '期末', '团队协作积极'),
(4, 6, 84.0, 'B', '2024-2025-1', '期末', '数据分析思路清晰'),
(5, 3, 87.0, 'B', '2024-2025-1', '期末', '响应式布局良好'),
(5, 4, 80.0, 'B', '2024-2025-1', '期末', '按时交付'),
(5, 6, 93.0, 'A', '2024-2025-1', '期末', '可视化图表美观'),
(6, 1, 72.0, 'C', '2024-2025-1', '期末', '基础需巩固'),
(6, 5, 81.0, 'B', '2024-2025-1', '期末', '网络实验完成'),
(6, 6, 78.0, 'C', '2024-2025-1', '期末', '数据分析基本达标');

-- 更新班级学生人数
UPDATE `class_info` SET `student_count` = 4 WHERE `id` = 1;
UPDATE `class_info` SET `student_count` = 2 WHERE `id` = 2;

-- 角色
INSERT INTO `sys_role` (`role_code`, `role_name`, `description`, `status`) VALUES
('ADMIN',   '管理员', '系统全部权限', 1),
('TEACHER', '教师',   '管理学生、课程与成绩', 1),
('STUDENT', '学生',   '客户端自助服务', 1);

-- 菜单（管理端）
INSERT INTO `sys_menu` (`parent_id`, `title`, `path`, `icon`, `sort_order`, `portal`, `status`) VALUES
(0, '数据概览', '/dashboard', 'dashboard', 1, 'admin', 1),
(0, '学生管理', '/students',  'students',  2, 'admin', 1),
(0, '班级管理', '/classes',   'classes',   3, 'admin', 1),
(0, '课程管理', '/courses',   'courses',   4, 'admin', 1),
(0, '成绩管理', '/grades',    'grades',    5, 'admin', 1),
(0, '角色管理', '/roles',     'roles',     6, 'admin', 1),
(0, '菜单管理', '/menus',     'menus',     7, 'admin', 1),
(0, '个人资料', '/profile',   'profile',   8, 'admin', 1);

-- 角色菜单：管理员全部
INSERT INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT 1, id FROM `sys_menu` WHERE `portal` = 'admin';

-- 角色菜单：教师（无角色/菜单/班级管理）
INSERT INTO `sys_role_menu` (`role_id`, `menu_id`) VALUES
(2, 1), (2, 2), (2, 4), (2, 5), (2, 8);
