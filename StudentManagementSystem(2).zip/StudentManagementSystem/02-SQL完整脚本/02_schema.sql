-- 学生管理系统 — 数据库完整结构
-- 数据库：rb_sms · MySQL 8.x
-- 执行顺序：01_create_database.sql → 本文件 → 03_mock_data.sql

USE `rb_sms`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 清理旧表（重建时使用）
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
DROP TABLE IF EXISTS `sys_menu`;
DROP TABLE IF EXISTS `sys_role`;
DROP TABLE IF EXISTS `grade`;
DROP TABLE IF EXISTS `enrollment`;
DROP TABLE IF EXISTS `student`;
DROP TABLE IF EXISTS `course`;
DROP TABLE IF EXISTS `class_info`;
DROP TABLE IF EXISTS `sys_user`;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------
-- 1. 系统用户表
-- ----------------------------
CREATE TABLE `sys_user` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username`    VARCHAR(50)  NOT NULL COMMENT '登录账号',
  `password`    VARCHAR(100) NOT NULL COMMENT '登录密码',
  `role`        VARCHAR(20)  NOT NULL COMMENT '角色：ADMIN/TEACHER/STUDENT',
  `name`        VARCHAR(50)  NOT NULL COMMENT '姓名',
  `phone`       VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  `email`       VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `avatar`      VARCHAR(500) DEFAULT NULL COMMENT '头像URL',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1启用 0禁用',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户';

-- ----------------------------
-- 2. 班级表
-- ----------------------------
CREATE TABLE `class_info` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `class_name`  VARCHAR(50)  NOT NULL COMMENT '班级名称',
  `grade`       VARCHAR(20)  DEFAULT NULL COMMENT '年级',
  `major`       VARCHAR(50)  DEFAULT NULL COMMENT '专业',
  `head_teacher` VARCHAR(50) DEFAULT NULL COMMENT '班主任',
  `student_count` INT        NOT NULL DEFAULT 0 COMMENT '学生人数',
  `description` VARCHAR(200) DEFAULT NULL COMMENT '描述',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_class_name` (`class_name`),
  KEY `idx_grade_major` (`grade`, `major`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='班级';

-- ----------------------------
-- 3. 学生表
-- ----------------------------
CREATE TABLE `student` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_no`  VARCHAR(20)  NOT NULL COMMENT '学号',
  `name`        VARCHAR(50)  NOT NULL COMMENT '姓名',
  `gender`      VARCHAR(10)  DEFAULT NULL COMMENT '性别',
  `birth_date`  DATE         DEFAULT NULL COMMENT '出生日期',
  `phone`       VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  `email`       VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `avatar`      VARCHAR(500) DEFAULT NULL COMMENT '头像URL',
  `class_id`    BIGINT       DEFAULT NULL COMMENT '班级ID',
  `user_id`     BIGINT       DEFAULT NULL COMMENT '关联用户ID',
  `address`     VARCHAR(200) DEFAULT NULL COMMENT '地址',
  `enroll_date` DATE         DEFAULT NULL COMMENT '入学日期',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1在读 0休学 2毕业',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_no` (`student_no`),
  KEY `idx_class_id` (`class_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_name` (`name`),
  CONSTRAINT `fk_student_class` FOREIGN KEY (`class_id`) REFERENCES `class_info` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_student_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='学生';

-- ----------------------------
-- 4. 课程表
-- ----------------------------
CREATE TABLE `course` (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `course_code`  VARCHAR(20)  NOT NULL COMMENT '课程编号',
  `course_name`  VARCHAR(100) NOT NULL COMMENT '课程名称',
  `credit`       INT          DEFAULT NULL COMMENT '学分',
  `teacher_name` VARCHAR(50)  DEFAULT NULL COMMENT '授课教师',
  `course_type`  VARCHAR(20)  DEFAULT '必修' COMMENT '课程类型：必修/选修',
  `hours`        INT          DEFAULT NULL COMMENT '学时',
  `description`  VARCHAR(200) DEFAULT NULL COMMENT '课程描述',
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_code` (`course_code`),
  KEY `idx_course_name` (`course_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程';

-- ----------------------------
-- 5. 选课记录表
-- ----------------------------
CREATE TABLE `enrollment` (
  `id`          BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_id`  BIGINT      NOT NULL COMMENT '学生ID',
  `course_id`   BIGINT      NOT NULL COMMENT '课程ID',
  `semester`    VARCHAR(20) DEFAULT NULL COMMENT '学期',
  `enroll_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '选课时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_course_semester` (`student_id`, `course_id`, `semester`),
  KEY `idx_enrollment_course` (`course_id`),
  CONSTRAINT `fk_enrollment_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_enrollment_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='选课记录';

-- ----------------------------
-- 6. 成绩表
-- ----------------------------
CREATE TABLE `grade` (
  `id`          BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_id`  BIGINT        NOT NULL COMMENT '学生ID',
  `course_id`   BIGINT        NOT NULL COMMENT '课程ID',
  `score`       DECIMAL(5,1)  DEFAULT NULL COMMENT '分数',
  `grade_level` VARCHAR(10)   DEFAULT NULL COMMENT '等级：A/B/C/D/F',
  `semester`    VARCHAR(20)   DEFAULT NULL COMMENT '学期',
  `exam_type`   VARCHAR(20)   DEFAULT '期末' COMMENT '考试类型',
  `remark`      VARCHAR(200)  DEFAULT NULL COMMENT '备注',
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '录入时间',
  PRIMARY KEY (`id`),
  KEY `idx_grade_student` (`student_id`),
  KEY `idx_grade_course` (`course_id`),
  KEY `idx_grade_semester` (`semester`),
  CONSTRAINT `fk_grade_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_grade_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成绩';

-- ----------------------------
-- 7. 角色表
-- ----------------------------
CREATE TABLE `sys_role` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `role_code`   VARCHAR(20)  NOT NULL COMMENT '角色编码',
  `role_name`   VARCHAR(50)  NOT NULL COMMENT '角色名称',
  `description` VARCHAR(200) DEFAULT NULL COMMENT '描述',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '1启用 0禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_code` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色';

-- ----------------------------
-- 8. 菜单表
-- ----------------------------
CREATE TABLE `sys_menu` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `parent_id`   BIGINT       NOT NULL DEFAULT 0 COMMENT '父菜单ID',
  `title`       VARCHAR(50)  NOT NULL COMMENT '菜单名称',
  `path`        VARCHAR(100) NOT NULL COMMENT '路由路径',
  `icon`        VARCHAR(50)  DEFAULT NULL COMMENT '图标标识',
  `sort_order`  INT          NOT NULL DEFAULT 0 COMMENT '排序',
  `portal`      VARCHAR(20)  NOT NULL DEFAULT 'admin' COMMENT '端：admin/client',
  `status`      TINYINT      NOT NULL DEFAULT 1 COMMENT '1启用 0禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='菜单';

-- ----------------------------
-- 9. 角色菜单关联
-- ----------------------------
CREATE TABLE `sys_role_menu` (
  `id`      BIGINT NOT NULL AUTO_INCREMENT,
  `role_id` BIGINT NOT NULL,
  `menu_id` BIGINT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_menu` (`role_id`, `menu_id`),
  CONSTRAINT `fk_rm_role` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rm_menu` FOREIGN KEY (`menu_id`) REFERENCES `sys_menu` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色菜单';
